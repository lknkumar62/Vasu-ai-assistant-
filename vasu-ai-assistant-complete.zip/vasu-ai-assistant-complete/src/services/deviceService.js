import { Platform } from 'react-native';
import * as IntentLauncher from 'expo-intent-launcher';
import * as Linking from 'expo-linking';

class DeviceService {
  // Open any app
  async openApp(packageName) {
    try {
      if (Platform.OS === 'android') {
        await IntentLauncher.startActivityAsync('android.intent.action.MAIN', {
          packageName,
          category: 'android.intent.category.LAUNCHER',
        });
        return { success: true };
      } else {
        // iOS - use URL schemes
        const urlScheme = this.getiOSUrlScheme(packageName);
        if (urlScheme) {
          const canOpen = await Linking.canOpenURL(urlScheme);
          if (canOpen) {
            await Linking.openURL(urlScheme);
            return { success: true };
          }
        }
        return { success: false, error: 'App not found' };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Get iOS URL scheme for common apps
  getiOSUrlScheme(appName) {
    const schemes = {
      'youtube': 'youtube://',
      'chrome': 'googlechrome://',
      'whatsapp': 'whatsapp://',
      'instagram': 'instagram://',
      'facebook': 'fb://',
      'twitter': 'twitter://',
      'gmail': 'googlegmail://',
      'maps': 'comgooglemaps://',
      'spotify': 'spotify://',
      'netflix': 'nflx://',
      'settings': 'app-settings://',
    };
    return schemes[appName.toLowerCase()];
  }

  // Make a call
  async makeCall(phoneNumber) {
    try {
      const url = `tel:${phoneNumber}`;
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
        return { success: true };
      }
      return { success: false, error: 'Cannot make calls' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Send SMS
  async sendSMS(phoneNumber, message) {
    try {
      const url = `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
        return { success: true };
      }
      return { success: false, error: 'Cannot send SMS' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Send WhatsApp
  async sendWhatsApp(phoneNumber, message) {
    try {
      const url = `whatsapp://send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
        return { success: true };
      }
      return { success: false, error: 'WhatsApp not installed' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Send Email
  async sendEmail(to, subject, body) {
    try {
      const url = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
        return { success: true };
      }
      return { success: false, error: 'Cannot send email' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Open URL in browser
  async openURL(url) {
    try {
      if (!url.startsWith('http')) {
        url = `https://${url}`;
      }
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
        return { success: true };
      }
      return { success: false, error: 'Cannot open URL' };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Search on Google
  async searchGoogle(query) {
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    return this.openURL(searchUrl);
  }

  // Search on YouTube
  async searchYouTube(query) {
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
    return this.openURL(searchUrl);
  }

  // Toggle settings (Android only - requires native modules)
  async toggleSetting(setting, value) {
    // This would require native modules for actual implementation
    // For now, return mock success
    return { 
      success: true, 
      message: `${setting} ${value ? 'enabled' : 'disabled'}` 
    };
  }

  // Get device info
  async getDeviceInfo() {
    return {
      platform: Platform.OS,
      version: Platform.Version,
      isPad: Platform.isPad,
      isTV: Platform.isTV,
    };
  }
}

export default new DeviceService();