import axios from 'axios';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3001';

class AIService {
  constructor() {
    this.baseURL = BACKEND_URL;
    this.headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENAI_API_KEY}`,
    };
  }

  // Process voice command with AI
  async processCommand(command, language = 'hi-EN', context = []) {
    try {
      const response = await axios.post(`${this.baseURL}/api/voice/process`, {
        command,
        language,
        context,
      });
      return response.data;
    } catch (error) {
      console.error('AI Process Error:', error);
      return {
        success: false,
        response: 'Maaf kijiye, server se connect nahi ho paya.',
      };
    }
  }

  // Generate code from voice description
  async generateCode(description, language = 'javascript', framework = 'react') {
    try {
      const response = await axios.post(`${this.baseURL}/api/code/generate`, {
        description,
        language,
        framework,
      });
      return response.data;
    } catch (error) {
      console.error('Code Generation Error:', error);
      return {
        success: false,
        code: '// Error generating code',
      };
    }
  }

  // Execute code
  async executeCode(code, language = 'javascript') {
    try {
      const response = await axios.post(`${this.baseURL}/api/code/execute`, {
        code,
        language,
      });
      return response.data;
    } catch (error) {
      console.error('Code Execution Error:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Automate web actions
  async automateWeb(url, actions) {
    try {
      const response = await axios.post(`${this.baseURL}/api/web/automate`, {
        url,
        actions,
      });
      return response.data;
    } catch (error) {
      console.error('Web Automation Error:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Deploy project
  async deployProject(platform, projectPath, projectName) {
    try {
      const response = await axios.post(`${this.baseURL}/api/deploy`, {
        platform,
        projectPath,
        projectName,
      });
      return response.data;
    } catch (error) {
      console.error('Deployment Error:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Execute system command
  async executeSystemCommand(command, requiresConfirmation = false) {
    try {
      const response = await axios.post(`${this.baseURL}/api/system/execute`, {
        command,
        requiresConfirmation,
      });
      return response.data;
    } catch (error) {
      console.error('System Command Error:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Save to memory
  async saveToMemory(userId, key, data) {
    try {
      const response = await axios.post(`${this.baseURL}/api/memory/save`, {
        userId,
        key,
        data,
      });
      return response.data;
    } catch (error) {
      console.error('Memory Save Error:', error);
      return { success: false };
    }
  }

  // Get from memory
  async getFromMemory(userId, key) {
    try {
      const response = await axios.get(`${this.baseURL}/api/memory/get/${userId}/${key}`);
      return response.data;
    } catch (error) {
      console.error('Memory Get Error:', error);
      return { success: false, data: null };
    }
  }

  // Health check
  async healthCheck() {
    try {
      const response = await axios.get(`${this.baseURL}/api/health`);
      return response.data;
    } catch (error) {
      return { status: 'offline', error: error.message };
    }
  }
}

export default new AIService();