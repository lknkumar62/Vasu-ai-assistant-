import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

class NotificationService {
  constructor() {
    this.configure();
  }

  configure() {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
      }),
    });
  }

  // Request permissions
  async requestPermissions() {
    if (Device.isDevice) {
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        return { success: false, error: 'Permission not granted' };
      }

      return { success: true };
    }
    return { success: false, error: 'Must use physical device' };
  }

  // Schedule local notification
  async scheduleNotification(title, body, trigger = null, data = {}) {
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          data,
          sound: 'default',
          priority: Notifications.AndroidNotificationPriority.HIGH,
        },
        trigger: trigger || { seconds: 1 },
      });
      return { success: true, id };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Schedule daily reminder
  async scheduleDailyReminder(hour, minute, title, body) {
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          sound: 'default',
        },
        trigger: {
          hour,
          minute,
          repeats: true,
        },
      });
      return { success: true, id };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Cancel notification
  async cancelNotification(id) {
    try {
      await Notifications.cancelScheduledNotificationAsync(id);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Cancel all notifications
  async cancelAllNotifications() {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Get all scheduled notifications
  async getScheduledNotifications() {
    try {
      const notifications = await Notifications.getAllScheduledNotificationsAsync();
      return { success: true, notifications };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // Show immediate notification
  async showNotification(title, body, data = {}) {
    return this.scheduleNotification(title, body, { seconds: 1 }, data);
  }

  // Set badge count
  async setBadgeCount(count) {
    try {
      await Notifications.setBadgeCountAsync(count);
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}

export default new NotificationService();