import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Switch,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSecurity } from '../context/SecurityContext';
import { useVoice } from '../context/VoiceContext';

export default function SecurityScreen() {
  const {
    isAuthenticated,
    voiceProfile,
    securitySettings,
    failedAttempts,
    enrollVoice,
    authenticateWithPIN,
    setPIN,
    updateSecuritySettings,
    getSecurityLogs,
    lock,
  } = useSecurity();

  const { speak } = useVoice();
  const [pin, setPinInput] = useState('');
  const [newPin, setNewPin] = useState('');
  const [showEnrollModal, setShowEnrollModal] = useState(false);
  const [enrollStep, setEnrollStep] = useState(0);
  const [voiceSamples, setVoiceSamples] = useState([]);

  const handleEnrollVoice = async () => {
    if (enrollStep < 3) {
      speak(`Please say "Vasu is my assistant" - Sample ${enrollStep + 1} of 3`);
      // Simulate voice capture
      setVoiceSamples([...voiceSamples, `sample_${enrollStep}`]);
      setEnrollStep(enrollStep + 1);
    } else {
      const success = await enrollVoice(voiceSamples);
      if (success) {
        speak('Voice enrollment complete! Aapki awaaz save ho gayi.');
        setShowEnrollModal(false);
        setEnrollStep(0);
        setVoiceSamples([]);
      }
    }
  };

  const handleSetPIN = async () => {
    if (newPin.length < 4) {
      Alert.alert('Error', 'PIN must be at least 4 digits');
      return;
    }
    await setPIN(newPin);
    speak('PIN set ho gayi.');
    setNewPin('');
  };

  const handleAuthWithPIN = async () => {
    const success = await authenticateWithPIN(pin);
    if (success) {
      speak('Authentication successful.');
      setPinInput('');
    } else {
      speak('Galat PIN. Dobara try karein.');
    }
  };

  const toggleSetting = async (key) => {
    await updateSecuritySettings({ [key]: !securitySettings[key] });
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Security</Text>
        <Text style={styles.subtitle}>
          {isAuthenticated ? '✅ Authenticated' : '🔒 Locked'}
        </Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Auth Status */}
        <View style={styles.authCard}>
          <View style={styles.authIcon}>
            <Ionicons 
              name={isAuthenticated ? "shield-checkmark" : "lock-closed"} 
              size={40} 
              color={isAuthenticated ? '#00ff88' : '#ff6b6b'} 
            />
          </View>
          <View style={styles.authInfo}>
            <Text style={styles.authStatus}>
              {isAuthenticated ? 'Voice Verified' : 'Authentication Required'}
            </Text>
            {failedAttempts > 0 && (
              <Text style={styles.authWarning}>
                Failed attempts: {failedAttempts}/3
              </Text>
            )}
          </View>
        </View>

        {/* Voice Authentication */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Voice Authentication</Text>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="mic" size={20} color="#00ff88" />
              <Text style={styles.toggleText}>Enable Voice Auth</Text>
            </View>
            <Switch
              value={securitySettings.voiceAuthEnabled}
              onValueChange={() => toggleSetting('voiceAuthEnabled')}
              trackColor={{ false: '#333', true: '#00ff8860' }}
              thumbColor={securitySettings.voiceAuthEnabled ? '#00ff88' : '#666'}
            />
          </View>

          <TouchableOpacity 
            style={styles.actionBtn}
            onPress={() => setShowEnrollModal(true)}
          >
            <Ionicons name="mic" size={20} color="#00ff88" />
            <Text style={styles.actionBtnText}>
              {voiceProfile ? 'Re-enroll Voice' : 'Enroll Voice'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* PIN Fallback */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PIN Fallback</Text>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="keypad" size={20} color="#00ccff" />
              <Text style={styles.toggleText}>Enable PIN Fallback</Text>
            </View>
            <Switch
              value={securitySettings.pinFallback}
              onValueChange={() => toggleSetting('pinFallback')}
              trackColor={{ false: '#333', true: '#00ccff60' }}
              thumbColor={securitySettings.pinFallback ? '#00ccff' : '#666'}
            />
          </View>

          <View style={styles.pinContainer}>
            <TextInput
              style={styles.pinInput}
              placeholder="Enter new PIN"
              placeholderTextColor="#666"
              value={newPin}
              onChangeText={setNewPin}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={6}
            />
            <TouchableOpacity 
              style={styles.pinBtn}
              onPress={handleSetPIN}
            >
              <Text style={styles.pinBtnText}>Set PIN</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.pinContainer}>
            <TextInput
              style={styles.pinInput}
              placeholder="Enter PIN to unlock"
              placeholderTextColor="#666"
              value={pin}
              onChangeText={setPinInput}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={6}
            />
            <TouchableOpacity 
              style={[styles.pinBtn, { backgroundColor: '#00ff88' }]}
              onPress={handleAuthWithPIN}
            >
              <Text style={[styles.pinBtnText, { color: '#0a0a0a' }]}>Unlock</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Safety Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Safety Settings</Text>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="warning" size={20} color="#ffe66d" />
              <Text style={styles.toggleText}>Confirm Risky Actions</Text>
            </View>
            <Switch
              value={securitySettings.confirmationForRisky}
              onValueChange={() => toggleSetting('confirmationForRisky')}
              trackColor={{ false: '#333', true: '#ffe66d60' }}
              thumbColor={securitySettings.confirmationForRisky ? '#ffe66d' : '#666'}
            />
          </View>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="finger-print" size={20} color="#ff6b6b" />
              <Text style={styles.toggleText}>Biometric Fallback</Text>
            </View>
            <Switch
              value={securitySettings.biometricFallback}
              onValueChange={() => toggleSetting('biometricFallback')}
              trackColor={{ false: '#333', true: '#ff6b6b60' }}
              thumbColor={securitySettings.biometricFallback ? '#ff6b6b' : '#666'}
            />
          </View>
        </View>

        {/* Security Log */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Security Log</Text>
          <TouchableOpacity 
            style={styles.actionBtn}
            onPress={async () => {
              const logs = await getSecurityLogs();
              Alert.alert('Security Logs', `Total events: ${logs.length}`);
            }}
          >
            <Ionicons name="document-text" size={20} color="#00ccff" />
            <Text style={styles.actionBtnText}>View Logs</Text>
          </TouchableOpacity>
        </View>

        {/* Lock Now */}
        <TouchableOpacity 
          style={[styles.lockBtn, { backgroundColor: '#ff6b6b20' }]}
          onPress={() => {
            lock();
            speak('Vasu locked. Voice authentication required.');
          }}
        >
          <Ionicons name="lock-closed" size={24} color="#ff6b6b" />
          <Text style={[styles.lockBtnText, { color: '#ff6b6b' }]}>Lock Vasu Now</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Voice Enroll Modal */}
      {showEnrollModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Voice Enrollment</Text>
            <Text style={styles.modalText}>
              Step {enrollStep + 1} of 3: Say "Vasu is my assistant"
            </Text>

            <View style={styles.enrollProgress}>
              {[0, 1, 2].map(i => (
                <View 
                  key={i} 
                  style={[
                    styles.enrollDot, 
                    i < enrollStep && styles.enrollDotComplete,
                    i === enrollStep && styles.enrollDotActive
                  ]} 
                />
              ))}
            </View>

            <TouchableOpacity 
              style={styles.enrollBtn}
              onPress={handleEnrollVoice}
            >
              <Ionicons name="mic" size={24} color="#0a0a0a" />
              <Text style={styles.enrollBtnText}>
                {enrollStep < 3 ? 'Record Sample' : 'Complete'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.cancelBtn}
              onPress={() => {
                setShowEnrollModal(false);
                setEnrollStep(0);
                setVoiceSamples([]);
              }}
            >
              <Text style={styles.cancelBtnText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#00ff88',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  authCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  authIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#00ff8810',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  authInfo: {
    flex: 1,
  },
  authStatus: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
  },
  authWarning: {
    color: '#ff6b6b',
    fontSize: 14,
    marginTop: 5,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#888',
    marginBottom: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  toggleItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1a1a1a',
    borderRadius: 10,
    padding: 15,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  toggleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  toggleText: {
    color: '#ffffff',
    fontSize: 15,
    marginLeft: 12,
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 10,
    padding: 15,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  actionBtnText: {
    color: '#00ff88',
    fontSize: 15,
    fontWeight: '600',
    marginLeft: 10,
  },
  pinContainer: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  pinInput: {
    flex: 1,
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 15,
    color: '#ffffff',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#333',
    marginRight: 10,
  },
  pinBtn: {
    backgroundColor: '#333',
    borderRadius: 10,
    paddingHorizontal: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pinBtnText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  lockBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15,
    borderRadius: 12,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#ff6b6b30',
  },
  lockBtnText: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 10,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#00000080',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 20,
    width: '100%',
    borderWidth: 1,
    borderColor: '#333',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 10,
  },
  modalText: {
    color: '#888',
    fontSize: 14,
    marginBottom: 20,
  },
  enrollProgress: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  enrollDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#333',
    marginHorizontal: 5,
  },
  enrollDotComplete: {
    backgroundColor: '#00ff88',
  },
  enrollDotActive: {
    backgroundColor: '#00ff88',
    transform: [{ scale: 1.2 }],
  },
  enrollBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#00ff88',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  enrollBtnText: {
    color: '#0a0a0a',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 10,
  },
  cancelBtn: {
    alignItems: 'center',
    padding: 10,
  },
  cancelBtnText: {
    color: '#666',
    fontSize: 14,
  },
});