import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVoice } from '../context/VoiceContext';

const PLATFORMS = [
  {
    id: 'vercel',
    name: 'Vercel',
    icon: 'triangle',
    color: '#ffffff',
    description: 'Fastest deployment for frontend',
  },
  {
    id: 'netlify',
    name: 'Netlify',
    icon: 'cloud-upload',
    color: '#00ad9f',
    description: 'JAMstack deployment',
  },
  {
    id: 'github',
    name: 'GitHub Pages',
    icon: 'logo-github',
    color: '#f5f5f5',
    description: 'Free static hosting',
  },
  {
    id: 'firebase',
    name: 'Firebase',
    icon: 'flame',
    color: '#ffca28',
    description: 'Google hosting + backend',
  },
];

const DEPLOYMENT_STEPS = [
  'Building project...',
  'Optimizing assets...',
  'Uploading files...',
  'Configuring DNS...',
  'Deployment complete!',
];

export default function DeploymentScreen() {
  const { speak } = useVoice();
  const [selectedPlatform, setSelectedPlatform] = useState(null);
  const [projectName, setProjectName] = useState('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [deployUrl, setDeployUrl] = useState('');
  const [deployHistory, setDeployHistory] = useState([]);

  const handleDeploy = async () => {
    if (!selectedPlatform || !projectName) {
      speak('Please select platform and enter project name.');
      return;
    }

    setIsDeploying(true);
    setCurrentStep(0);
    speak(`Deploying to ${selectedPlatform.name}...`);

    // Simulate deployment steps
    for (let i = 0; i < DEPLOYMENT_STEPS.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setCurrentStep(i);
    }

    const url = `https://${projectName.toLowerCase().replace(/\s/g, '-')}.${selectedPlatform.id}.app`;
    setDeployUrl(url);

    setDeployHistory([
      {
        id: Date.now(),
        project: projectName,
        platform: selectedPlatform.name,
        url,
        timestamp: new Date().toISOString(),
        status: 'success',
      },
      ...deployHistory,
    ]);

    setIsDeploying(false);
    speak(`Deployment complete! App live at ${url}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Deployment</Text>
        <Text style={styles.subtitle}>Voice se deploy karein</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Platform Selection */}
        <Text style={styles.sectionTitle}>Select Platform</Text>
        <View style={styles.platformsGrid}>
          {PLATFORMS.map((platform) => (
            <TouchableOpacity
              key={platform.id}
              style={[
                styles.platformCard,
                selectedPlatform?.id === platform.id && styles.platformCardActive,
              ]}
              onPress={() => {
                setSelectedPlatform(platform);
                speak(`${platform.name} select kiya.`);
              }}
            >
              <View style={[styles.platformIcon, { backgroundColor: platform.color + '20' }]}>
                <Ionicons name={platform.icon} size={28} color={platform.color} />
              </View>
              <Text style={styles.platformName}>{platform.name}</Text>
              <Text style={styles.platformDesc}>{platform.description}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Project Details */}
        <View style={styles.inputCard}>
          <Text style={styles.inputLabel}>Project Name:</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., my-awesome-app"
            placeholderTextColor="#666"
            value={projectName}
            onChangeText={setProjectName}
          />
        </View>

        {/* Deploy Button */}
        <TouchableOpacity 
          style={[
            styles.deployBtn,
            (!selectedPlatform || !projectName || isDeploying) && styles.deployBtnDisabled,
          ]}
          onPress={handleDeploy}
          disabled={!selectedPlatform || !projectName || isDeploying}
        >
          {isDeploying ? (
            <ActivityIndicator color="#0a0a0a" />
          ) : (
            <>
              <Ionicons name="rocket" size={24} color="#0a0a0a" />
              <Text style={styles.deployBtnText}>Deploy Now</Text>
            </>
          )}
        </TouchableOpacity>

        {/* Deployment Progress */}
        {isDeploying && (
          <View style={styles.progressCard}>
            <Text style={styles.progressTitle}>Deploying...</Text>
            {DEPLOYMENT_STEPS.map((step, index) => (
              <View key={index} style={styles.stepItem}>
                <Ionicons 
                  name={index <= currentStep ? "checkmark-circle" : "ellipse-outline"} 
                  size={20} 
                  color={index <= currentStep ? '#00ff88' : '#666'} 
                />
                <Text style={[
                  styles.stepText,
                  index <= currentStep && styles.stepTextActive,
                ]}>
                  {step}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* Deploy URL */}
        {deployUrl && !isDeploying && (
          <View style={styles.urlCard}>
            <Text style={styles.urlTitle}>🎉 Live URL</Text>
            <Text style={styles.urlText}>{deployUrl}</Text>
            <TouchableOpacity 
              style={styles.openUrlBtn}
              onPress={() => speak(`Opening ${deployUrl}`)}
            >
              <Text style={styles.openUrlText}>Open in Browser</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Deployment History */}
        {deployHistory.length > 0 && (
          <View style={styles.historySection}>
            <Text style={styles.sectionTitle}>Deployment History</Text>
            {deployHistory.map((deploy) => (
              <View key={deploy.id} style={styles.historyCard}>
                <View style={styles.historyHeader}>
                  <Text style={styles.historyProject}>{deploy.project}</Text>
                  <View style={styles.historyStatus}>
                    <Text style={styles.statusText}>{deploy.platform}</Text>
                  </View>
                </View>
                <Text style={styles.historyUrl}>{deploy.url}</Text>
                <Text style={styles.historyTime}>
                  {new Date(deploy.timestamp).toLocaleString()}
                </Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#00ff88',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
    marginTop: 10,
  },
  platformsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  platformCard: {
    width: '48%',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  platformCardActive: {
    borderColor: '#00ff88',
    backgroundColor: '#00ff8810',
  },
  platformIcon: {
    width: 50,
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  platformName: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  platformDesc: {
    color: '#666',
    fontSize: 12,
    marginTop: 4,
  },
  inputCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  inputLabel: {
    color: '#888',
    fontSize: 14,
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 15,
    color: '#ffffff',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#333',
  },
  deployBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#00ff88',
    borderRadius: 12,
    padding: 18,
    marginBottom: 20,
  },
  deployBtnDisabled: {
    backgroundColor: '#333',
  },
  deployBtnText: {
    color: '#0a0a0a',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  progressCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  progressTitle: {
    color: '#00ff88',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 15,
  },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  stepText: {
    color: '#666',
    fontSize: 14,
    marginLeft: 10,
  },
  stepTextActive: {
    color: '#00ff88',
  },
  urlCard: {
    backgroundColor: '#00ff8810',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#00ff8830',
    alignItems: 'center',
  },
  urlTitle: {
    color: '#00ff88',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  urlText: {
    color: '#ffffff',
    fontSize: 16,
    marginBottom: 15,
  },
  openUrlBtn: {
    backgroundColor: '#00ff88',
    borderRadius: 8,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  openUrlText: {
    color: '#0a0a0a',
    fontSize: 14,
    fontWeight: '600',
  },
  historySection: {
    marginBottom: 30,
  },
  historyCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  historyProject: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  historyStatus: {
    backgroundColor: '#00ff8820',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  statusText: {
    color: '#00ff88',
    fontSize: 12,
  },
  historyUrl: {
    color: '#00ccff',
    fontSize: 13,
    marginBottom: 5,
  },
  historyTime: {
    color: '#666',
    fontSize: 12,
  },
});