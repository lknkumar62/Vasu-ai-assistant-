import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVasu } from '../context/VasuContext';
import { useVoice } from '../context/VoiceContext';

export default function AccessibilityScreen() {
  const { state, setMode } = useVasu();
  const { speak } = useVoice();

  const [accessibilitySettings, setAccessibilitySettings] = React.useState({
    screenReader: false,
    highContrast: false,
    largeText: false,
    reduceMotion: false,
    colorBlindMode: false,
    voiceFeedback: true,
    hapticFeedback: true,
    autoReadNotifications: false,
    gestureNavigation: true,
    shakeToActivate: true,
  });

  const toggleSetting = (key) => {
    setAccessibilitySettings(prev => ({ ...prev, [key]: !prev[key] }));
    if (key === 'voiceFeedback') {
      speak('Voice feedback toggle ho gayi.');
    }
  };

  const features = [
    {
      title: 'Screen Reader',
      description: 'Har element ko awaaz mein padhein',
      icon: 'ear',
      key: 'screenReader',
      color: '#00ff88',
    },
    {
      title: 'High Contrast',
      description: 'Colors ko zyada clear banayein',
      icon: 'contrast',
      key: 'highContrast',
      color: '#ffffff',
    },
    {
      title: 'Large Text',
      description: 'Text size badhayein',
      icon: 'text',
      key: 'largeText',
      color: '#c7ceea',
    },
    {
      title: 'Reduce Motion',
      description: 'Animations ko kam karein',
      icon: 'speedometer',
      key: 'reduceMotion',
      color: '#ffe66d',
    },
    {
      title: 'Color Blind Mode',
      description: 'Color blind friendly colors',
      icon: 'eye',
      key: 'colorBlindMode',
      color: '#ff6b6b',
    },
    {
      title: 'Voice Feedback',
      description: 'Har action ki awaaz feedback',
      icon: 'volume-high',
      key: 'voiceFeedback',
      color: '#00ccff',
    },
    {
      title: 'Haptic Feedback',
      description: 'Vibration feedback',
      icon: 'hand-left',
      key: 'hapticFeedback',
      color: '#a8e6cf',
    },
    {
      title: 'Auto Read Notifications',
      description: 'Notifications automatically padhein',
      icon: 'notifications',
      key: 'autoReadNotifications',
      color: '#ff8b94',
    },
    {
      title: 'Gesture Navigation',
      description: 'Swipe gestures se control karein',
      icon: 'hand-right',
      key: 'gestureNavigation',
      color: '#4ecdc4',
    },
    {
      title: 'Shake to Activate',
      description: 'Phone hila ke Vasu ko bulayein',
      icon: 'phone-portrait',
      key: 'shakeToActivate',
      color: '#ffd93d',
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Accessibility</Text>
        <Text style={styles.subtitle}>Vasu sabke liye</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Accessibility Mode Toggle */}
        <View style={styles.modeCard}>
          <View style={styles.modeInfo}>
            <Ionicons name="accessibility" size={30} color="#00ff88" />
            <View style={styles.modeText}>
              <Text style={styles.modeTitle}>Full Accessibility Mode</Text>
              <Text style={styles.modeDesc}>Maximum voice control, minimum touch</Text>
            </View>
          </View>
          <TouchableOpacity 
            style={[
              styles.modeBtn, 
              state.activeMode === 'accessibility' && styles.modeBtnActive
            ]}
            onPress={() => {
              const newMode = state.activeMode === 'accessibility' ? 'normal' : 'accessibility';
              setMode(newMode);
              speak(newMode === 'accessibility' ? 'Accessibility mode on.' : 'Normal mode on.');
            }}
          >
            <Text style={[
              styles.modeBtnText,
              state.activeMode === 'accessibility' && styles.modeBtnTextActive
            ]}>
              {state.activeMode === 'accessibility' ? 'ON' : 'OFF'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Features List */}
        <Text style={styles.sectionTitle}>Features</Text>

        {features.map((feature) => (
          <View key={feature.key} style={styles.featureCard}>
            <View style={[styles.featureIcon, { backgroundColor: feature.color + '20' }]}>
              <Ionicons name={feature.icon} size={24} color={feature.color} />
            </View>
            <View style={styles.featureInfo}>
              <Text style={styles.featureTitle}>{feature.title}</Text>
              <Text style={styles.featureDesc}>{feature.description}</Text>
            </View>
            <Switch
              value={accessibilitySettings[feature.key]}
              onValueChange={() => toggleSetting(feature.key)}
              trackColor={{ false: '#333', true: feature.color + '60' }}
              thumbColor={accessibilitySettings[feature.key] ? feature.color : '#666'}
            />
          </View>
        ))}

        {/* Quick Help */}
        <View style={styles.helpCard}>
          <Text style={styles.helpTitle}>Quick Voice Commands</Text>
          <View style={styles.helpItem}>
            <Text style={styles.helpCmd}>"Vasu, screen reader on"</Text>
          </View>
          <View style={styles.helpItem}>
            <Text style={styles.helpCmd}>"Vasu, text bada karo"</Text>
          </View>
          <View style={styles.helpItem}>
            <Text style={styles.helpCmd}>"Vasu, contrast badhao"</Text>
          </View>
          <View style={styles.helpItem}>
            <Text style={styles.helpCmd}>"Vasu, kya hai screen pe"</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#00ff88',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  modeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  modeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  modeText: {
    marginLeft: 15,
  },
  modeTitle: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  modeDesc: {
    color: '#888',
    fontSize: 13,
    marginTop: 2,
  },
  modeBtn: {
    backgroundColor: '#333',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 8,
  },
  modeBtnActive: {
    backgroundColor: '#00ff88',
  },
  modeBtnText: {
    color: '#888',
    fontSize: 14,
    fontWeight: '600',
  },
  modeBtnTextActive: {
    color: '#0a0a0a',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#888',
    marginBottom: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  featureCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  featureIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureInfo: {
    flex: 1,
    marginLeft: 12,
  },
  featureTitle: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '600',
  },
  featureDesc: {
    color: '#666',
    fontSize: 13,
    marginTop: 2,
  },
  helpCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginTop: 20,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#333',
  },
  helpTitle: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  helpItem: {
    backgroundColor: '#222',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  helpCmd: {
    color: '#00ff88',
    fontSize: 14,
    fontStyle: 'italic',
  },
});