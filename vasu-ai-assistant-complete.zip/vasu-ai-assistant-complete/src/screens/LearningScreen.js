import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMemory } from '../context/MemoryContext';
import { useVoice } from '../context/VoiceContext';

const LEARNING_TOPICS = [
  { id: 'spanish', name: 'Spanish', icon: 'language', color: '#ff6b6b', items: 50 },
  { id: 'german', name: 'German', icon: 'language', color: '#ffe66d', items: 30 },
  { id: 'coding', name: 'Coding', icon: 'code-slash', color: '#00ff88', items: 100 },
  { id: 'gk', name: 'General Knowledge', icon: 'book', color: '#00ccff', items: 200 },
  { id: 'math', name: 'Math Tricks', icon: 'calculator', color: '#a8e6cf', items: 40 },
  { id: 'history', name: 'History', icon: 'time', color: '#c7ceea', items: 60 },
];

export default function LearningScreen() {
  const { 
    addLearningItem, 
    reviewItem, 
    getDueItems,
    learningItems,
    getMemoryStats,
  } = useMemory();

  const { speak } = useVoice();
  const [activeTopic, setActiveTopic] = useState(null);
  const [currentItem, setCurrentItem] = useState(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [studyMode, setStudyMode] = useState('learn'); // learn, quiz, review
  const [newContent, setNewContent] = useState('');
  const [stats, setStats] = useState({});

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const s = await getMemoryStats();
    setStats(s);
  };

  const startLearning = async (topic) => {
    setActiveTopic(topic);
    setStudyMode('learn');
    speak(`${topic.name} sikhna shuru karte hain!`);

    // Add sample items for demo
    if (topic.id === 'spanish') {
      await addLearningItem('Uno = One (1)');
      await addLearningItem('Dos = Two (2)');
      await addLearningItem('Tres = Three (3)');
    }
  };

  const handleReview = async (confidence) => {
    if (currentItem) {
      await reviewItem(currentItem.id, confidence);
      setShowAnswer(false);
      loadNextItem();
    }
  };

  const loadNextItem = async () => {
    const due = await getDueItems();
    if (due.length > 0) {
      setCurrentItem(due[0]);
      speak(due[0].content);
    } else {
      setCurrentItem(null);
      speak('Sab kuch yaad hai! Aap great hain!');
    }
  };

  const handleAddCustom = async () => {
    if (!newContent.trim()) return;
    await addLearningItem(newContent);
    setNewContent('');
    speak('Naya item add ho gaya!');
    loadStats();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Faster Than Brain</Text>
        <Text style={styles.subtitle}>AI-powered learning mode</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statPill}>
            <Text style={styles.statNum}>{stats.totalLearningItems || 0}</Text>
            <Text style={styles.statLabel}>Items</Text>
          </View>
          <View style={styles.statPill}>
            <Text style={styles.statNum}>{stats.masteredItems || 0}</Text>
            <Text style={styles.statLabel}>Mastered</Text>
          </View>
          <View style={styles.statPill}>
            <Text style={styles.statNum}>{stats.dueItems || 0}</Text>
            <Text style={styles.statLabel}>Due</Text>
          </View>
        </View>

        {/* Study Mode Tabs */}
        <View style={styles.modeTabs}>
          {['learn', 'quiz', 'review'].map((mode) => (
            <TouchableOpacity
              key={mode}
              style={[styles.modeTab, studyMode === mode && styles.modeTabActive]}
              onPress={() => {
                setStudyMode(mode);
                speak(`${mode} mode on.`);
              }}
            >
              <Text style={[styles.modeTabText, studyMode === mode && styles.modeTabTextActive]}>
                {mode.charAt(0).toUpperCase() + mode.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Topics Grid */}
        {!activeTopic && (
          <>
            <Text style={styles.sectionTitle}>Choose Topic</Text>
            <View style={styles.topicsGrid}>
              {LEARNING_TOPICS.map((topic) => (
                <TouchableOpacity
                  key={topic.id}
                  style={styles.topicCard}
                  onPress={() => startLearning(topic)}
                >
                  <View style={[styles.topicIcon, { backgroundColor: topic.color + '20' }]}>
                    <Ionicons name={topic.icon} size={28} color={topic.color} />
                  </View>
                  <Text style={styles.topicName}>{topic.name}</Text>
                  <Text style={styles.topicItems}>{topic.items} items</Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        {/* Active Learning */}
        {activeTopic && (
          <View style={styles.learningCard}>
            <View style={styles.learningHeader}>
              <Text style={styles.learningTitle}>{activeTopic.name}</Text>
              <TouchableOpacity onPress={() => setActiveTopic(null)}>
                <Ionicons name="close" size={24} color="#666" />
              </TouchableOpacity>
            </View>

            {currentItem ? (
              <>
                <View style={styles.contentCard}>
                  <Text style={styles.contentText}>{currentItem.content}</Text>
                </View>

                {showAnswer && (
                  <View style={styles.answerCard}>
                    <Text style={styles.answerLabel}>Answer:</Text>
                    <Text style={styles.answerText}>{currentItem.content}</Text>
                  </View>
                )}

                <View style={styles.reviewButtons}>
                  <TouchableOpacity 
                    style={[styles.reviewBtn, { backgroundColor: '#ff6b6b' }]}
                    onPress={() => handleReview(30)}
                  >
                    <Text style={styles.reviewBtnText}>Hard</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.reviewBtn, { backgroundColor: '#ffe66d' }]}
                    onPress={() => handleReview(60)}
                  >
                    <Text style={styles.reviewBtnText}>Good</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.reviewBtn, { backgroundColor: '#00ff88' }]}
                    onPress={() => handleReview(90)}
                  >
                    <Text style={styles.reviewBtnText}>Easy</Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : (
              <View style={styles.emptyLearning}>
                <Ionicons name="checkmark-circle" size={48} color="#00ff88" />
                <Text style={styles.emptyTitle}>All caught up!</Text>
                <TouchableOpacity 
                  style={styles.startBtn}
                  onPress={loadNextItem}
                >
                  <Text style={styles.startBtnText}>Start Review</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}

        {/* Add Custom Item */}
        <View style={styles.addCard}>
          <Text style={styles.addTitle}>Add Custom Item</Text>
          <TextInput
            style={styles.addInput}
            placeholder="e.g., Capital of France = Paris"
            placeholderTextColor="#666"
            value={newContent}
            onChangeText={setNewContent}
          />
          <TouchableOpacity style={styles.addBtn} onPress={handleAddCustom}>
            <Ionicons name="add" size={20} color="#0a0a0a" />
            <Text style={styles.addBtnText}>Add to Memory</Text>
          </TouchableOpacity>
        </View>

        {/* Voice Commands Help */}
        <View style={styles.helpCard}>
          <Text style={styles.helpTitle}>Voice Commands</Text>
          <View style={styles.helpItem}>
            <Ionicons name="mic" size={16} color="#00ff88" />
            <Text style={styles.helpText}>"Teach me Spanish numbers"</Text>
          </View>
          <View style={styles.helpItem}>
            <Ionicons name="mic" size={16} color="#00ff88" />
            <Text style={styles.helpText}>"Quiz me on capitals"</Text>
          </View>
          <View style={styles.helpItem}>
            <Ionicons name="mic" size={16} color="#00ff88" />
            <Text style={styles.helpText}>"Start revision"</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#00ff88',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statPill: {
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
  statNum: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00ff88',
  },
  statLabel: {
    fontSize: 12,
    color: '#888',
    marginTop: 2,
  },
  modeTabs: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  modeTab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 5,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
  },
  modeTabActive: {
    backgroundColor: '#00ff8820',
    borderColor: '#00ff88',
  },
  modeTabText: {
    color: '#888',
    fontSize: 14,
    fontWeight: '600',
  },
  modeTabTextActive: {
    color: '#00ff88',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
  },
  topicsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  topicCard: {
    width: '48%',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
    alignItems: 'center',
  },
  topicIcon: {
    width: 50,
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  topicName: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  topicItems: {
    color: '#666',
    fontSize: 12,
    marginTop: 4,
  },
  learningCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  learningHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  learningTitle: {
    color: '#00ff88',
    fontSize: 18,
    fontWeight: 'bold',
  },
  contentCard: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 20,
    marginBottom: 15,
    alignItems: 'center',
  },
  contentText: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: '600',
    textAlign: 'center',
  },
  answerCard: {
    backgroundColor: '#00ff8810',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  answerLabel: {
    color: '#00ff88',
    fontSize: 12,
    marginBottom: 5,
  },
  answerText: {
    color: '#ffffff',
    fontSize: 16,
  },
  reviewButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  reviewBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  reviewBtnText: {
    color: '#0a0a0a',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyLearning: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  emptyTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 10,
    marginBottom: 15,
  },
  startBtn: {
    backgroundColor: '#00ff88',
    borderRadius: 8,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  startBtnText: {
    color: '#0a0a0a',
    fontSize: 14,
    fontWeight: '600',
  },
  addCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  addTitle: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 10,
  },
  addInput: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 15,
    color: '#ffffff',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#333',
    marginBottom: 10,
  },
  addBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#00ff88',
    borderRadius: 8,
    padding: 12,
  },
  addBtnText: {
    color: '#0a0a0a',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 5,
  },
  helpCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#333',
  },
  helpTitle: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  helpItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  helpText: {
    color: '#888',
    fontSize: 14,
    marginLeft: 8,
  },
});