import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Animated,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons, MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { useVasu } from '../context/VasuContext';
import { useVoice } from '../context/VoiceContext';
import { useMemory } from '../context/MemoryContext';
import VoiceWaveform from '../components/VoiceWaveform';
import StatusBar from '../components/StatusBar';

const { width, height } = Dimensions.get('window');

export default function HomeScreen() {
  const navigation = useNavigation();
  const { state } = useVasu();
  const { isListening, voiceLevel, startVoiceRecognition, stopVoiceRecognition, speak } = useVoice();
  const { getSuggestions } = useMemory();

  const [suggestions, setSuggestions] = React.useState([]);
  const pulseAnim = React.useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Load suggestions based on habits
    loadSuggestions();

    // Pulse animation for mic button
    if (isListening) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.2,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isListening]);

  const loadSuggestions = async () => {
    const habits = await getSuggestions();
    setSuggestions(habits);
  };

  const handleMicPress = () => {
    if (isListening) {
      stopVoiceRecognition();
    } else {
      startVoiceRecognition();
      speak('Haan ji, main sun raha hoon.');
    }
  };

  const quickActions = [
    { icon: 'call', label: 'Call', screen: 'Voice', color: '#00ff88' },
    { icon: 'chatbubble', label: 'Message', screen: 'Voice', color: '#00ccff' },
    { icon: 'wifi', label: 'WiFi', action: () => speak('WiFi toggle kar raha hoon.'), color: '#ff6b6b' },
    { icon: 'bluetooth', label: 'Bluetooth', action: () => speak('Bluetooth toggle kar raha hoon.'), color: '#4ecdc4' },
    { icon: 'flashlight', label: 'Flash', action: () => speak('Flashlight toggle kar raha hoon.'), color: '#ffe66d' },
    { icon: 'musical-notes', label: 'Music', screen: 'Voice', color: '#a8e6cf' },
    { icon: 'code-slash', label: 'Code', screen: 'Coding', color: '#ff8b94' },
    { icon: 'rocket', label: 'Deploy', screen: 'Deployment', color: '#c7ceea' },
  ];

  return (
    <View style={styles.container}>
      <StatusBar />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.greeting}>Namaste! 🙏</Text>
        <Text style={styles.subGreeting}>
          {state.systemStatus === 'listening' ? 'Sun raha hoon...' : 
           state.systemStatus === 'processing' ? 'Soch raha hoon...' : 
           'Aapki seva mein hazir'}
        </Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Voice Waveform */}
        <View style={styles.waveformContainer}>
          <VoiceWaveform level={voiceLevel} isListening={isListening} />
        </View>

        {/* Quick Actions Grid */}
        <View style={styles.quickActionsContainer}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsGrid}>
            {quickActions.map((action, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.actionButton, { backgroundColor: action.color + '20' }]}
                onPress={() => {
                  if (action.screen) {
                    navigation.navigate(action.screen);
                  } else if (action.action) {
                    action.action();
                  }
                }}
              >
                <Ionicons name={action.icon} size={28} color={action.color} />
                <Text style={[styles.actionLabel, { color: action.color }]}>{action.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Suggestions based on habits */}
        {suggestions.length > 0 && (
          <View style={styles.suggestionsContainer}>
            <Text style={styles.sectionTitle}>Aapke liye</Text>
            {suggestions.map((suggestion, index) => (
              <TouchableOpacity
                key={index}
                style={styles.suggestionCard}
                onPress={() => speak(`${suggestion.action} kar raha hoon.`)}
              >
                <Ionicons name="time" size={20} color="#00ff88" />
                <View style={styles.suggestionText}>
                  <Text style={styles.suggestionAction}>{suggestion.action}</Text>
                  <Text style={styles.suggestionContext}>{suggestion.context}</Text>
                </View>
                <Text style={styles.confidence}>{Math.round(suggestion.confidence)}%</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Recent Commands */}
        {state.commandHistory.length > 0 && (
          <View style={styles.historyContainer}>
            <Text style={styles.sectionTitle}>Recent Commands</Text>
            {state.commandHistory.slice(0, 5).map((cmd, index) => (
              <View key={index} style={styles.historyItem}>
                <Text style={styles.historyCommand}>{cmd.command}</Text>
                <Text style={styles.historyTime}>
                  {new Date(cmd.timestamp).toLocaleTimeString()}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* Feature Cards */}
        <View style={styles.featuresContainer}>
          <Text style={styles.sectionTitle}>Features</Text>

          <TouchableOpacity 
            style={styles.featureCard}
            onPress={() => navigation.navigate('Automation')}
          >
            <View style={[styles.featureIcon, { backgroundColor: '#ff6b6b20' }]}>
              <Ionicons name="repeat" size={24} color="#ff6b6b" />
            </View>
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>Automation</Text>
              <Text style={styles.featureDesc}>Create voice shortcuts & routines</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#666" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.featureCard}
            onPress={() => navigation.navigate('Memory')}
          >
            <View style={[styles.featureIcon, { backgroundColor: '#4ecdc420' }]}>
              <Ionicons name="brain" size={24} color="#4ecdc4" />
            </View>
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>Memory & Learning</Text>
              <Text style={styles.featureDesc}>Faster than brain learning mode</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#666" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.featureCard}
            onPress={() => navigation.navigate('Coding')}
          >
            <View style={[styles.featureIcon, { backgroundColor: '#ffe66d20' }]}>
              <Ionicons name="code-slash" size={24} color="#ffe66d" />
            </View>
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>AI Coding</Text>
              <Text style={styles.featureDesc}>Build apps with voice commands</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#666" />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.featureCard}
            onPress={() => navigation.navigate('Security')}
          >
            <View style={[styles.featureIcon, { backgroundColor: '#a8e6cf20' }]}>
              <Ionicons name="shield-checkmark" size={24} color="#a8e6cf" />
            </View>
            <View style={styles.featureText}>
              <Text style={styles.featureTitle}>Security</Text>
              <Text style={styles.featureDesc}>Voice authentication & safety</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#666" />
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Main Mic Button */}
      <View style={styles.micContainer}>
        <Animated.View style={[styles.micRing, { transform: [{ scale: pulseAnim }] }]}>
          <TouchableOpacity
            style={[styles.micButton, isListening && styles.micButtonActive]}
            onPress={handleMicPress}
            activeOpacity={0.8}
          >
            <Ionicons 
              name={isListening ? "mic" : "mic-outline"} 
              size={40} 
              color={isListening ? "#0a0a0a" : "#00ff88"} 
            />
          </TouchableOpacity>
        </Animated.View>
        <Text style={styles.micHint}>
          {isListening ? 'Boliye...' : 'Tap to speak'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  greeting: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subGreeting: {
    fontSize: 16,
    color: '#00ff88',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
  },
  waveformContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  quickActionsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  actionButton: {
    width: (width - 60) / 4,
    height: (width - 60) / 4,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  actionLabel: {
    fontSize: 11,
    marginTop: 5,
    fontWeight: '600',
  },
  suggestionsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  suggestionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  suggestionText: {
    flex: 1,
    marginLeft: 10,
  },
  suggestionAction: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  suggestionContext: {
    color: '#888',
    fontSize: 12,
    marginTop: 2,
  },
  confidence: {
    color: '#00ff88',
    fontSize: 12,
    fontWeight: 'bold',
  },
  historyContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  historyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  historyCommand: {
    color: '#ffffff',
    fontSize: 14,
    flex: 1,
  },
  historyTime: {
    color: '#666',
    fontSize: 12,
  },
  featuresContainer: {
    paddingHorizontal: 20,
    marginBottom: 100,
  },
  featureCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureText: {
    flex: 1,
    marginLeft: 15,
  },
  featureTitle: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  featureDesc: {
    color: '#888',
    fontSize: 13,
    marginTop: 2,
  },
  micContainer: {
    position: 'absolute',
    bottom: 30,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  micRing: {
    borderRadius: 50,
    padding: 5,
    backgroundColor: '#00ff8830',
  },
  micButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#1a1a1a',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#00ff88',
    shadowColor: '#00ff88',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  micButtonActive: {
    backgroundColor: '#00ff88',
    borderColor: '#00ff88',
  },
  micHint: {
    color: '#888',
    fontSize: 14,
    marginTop: 10,
  },
});