import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAutomation } from '../context/AutomationContext';
import { useVoice } from '../context/VoiceContext';

const SAMPLE_ROUTINES = [
  {
    id: '1',
    name: 'Good Morning',
    trigger: 'Good Morning',
    actions: [
      { type: 'SET_SETTING', data: 'brightness: 80' },
      { type: 'OPEN_APP', data: 'calendar' },
      { type: 'NOTIFICATION', data: { title: 'Good Morning!', body: 'Have a great day!' } },
    ],
    isActive: true,
    executionCount: 12,
  },
  {
    id: '2',
    name: 'Movie Night',
    trigger: 'Movie Night',
    actions: [
      { type: 'SET_SETTING', data: 'brightness: 20' },
      { type: 'SET_SETTING', data: 'volume: 70' },
      { type: 'OPEN_APP', data: 'netflix' },
    ],
    isActive: true,
    executionCount: 5,
  },
  {
    id: '3',
    name: 'Work Mode',
    trigger: 'Work Mode',
    actions: [
      { type: 'SET_SETTING', data: 'do_not_disturb: on' },
      { type: 'OPEN_APP', data: 'vscode' },
      { type: 'OPEN_APP', data: 'chrome' },
    ],
    isActive: false,
    executionCount: 8,
  },
];

export default function AutomationScreen() {
  const { 
    routines, 
    createRoutine, 
    executeRoutine, 
    deleteRoutine, 
    toggleRoutine,
    scheduleTask 
  } = useAutomation();

  const { speak } = useVoice();
  const [localRoutines, setLocalRoutines] = useState(SAMPLE_ROUTINES);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newRoutineName, setNewRoutineName] = useState('');
  const [newTrigger, setNewTrigger] = useState('');
  const [actions, setActions] = useState([]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [taskName, setTaskName] = useState('');
  const [taskTime, setTaskTime] = useState('');

  const handleExecute = (routine) => {
    speak(`${routine.name} routine chala raha hoon.`);
    executeRoutine(routine.id);
  };

  const handleCreateRoutine = () => {
    if (!newRoutineName || !newTrigger) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    const newRoutine = {
      id: Date.now().toString(),
      name: newRoutineName,
      trigger: newTrigger,
      actions: actions,
      isActive: true,
      executionCount: 0,
    };

    setLocalRoutines([...localRoutines, newRoutine]);
    createRoutine(newRoutineName, newTrigger, actions);

    setShowCreateModal(false);
    setNewRoutineName('');
    setNewTrigger('');
    setActions([]);

    speak('Nayi routine create ho gayi!');
  };

  const handleScheduleTask = () => {
    if (!taskName || !taskTime) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    scheduleTask({
      name: taskName,
      time: new Date(taskTime).getTime(),
    });

    setShowScheduleModal(false);
    setTaskName('');
    setTaskTime('');

    speak('Task schedule ho gayi!');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Automation</Text>
        <Text style={styles.subtitle}>Create voice shortcuts & routines</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity 
            style={[styles.actionBtn, { backgroundColor: '#00ff8820' }]}
            onPress={() => setShowCreateModal(true)}
          >
            <Ionicons name="add-circle" size={24} color="#00ff88" />
            <Text style={[styles.actionBtnText, { color: '#00ff88' }]}>New Routine</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.actionBtn, { backgroundColor: '#00ccff20' }]}
            onPress={() => setShowScheduleModal(true)}
          >
            <Ionicons name="time" size={24} color="#00ccff" />
            <Text style={[styles.actionBtnText, { color: '#00ccff' }]}>Schedule Task</Text>
          </TouchableOpacity>
        </View>

        {/* Routines List */}
        <Text style={styles.sectionTitle}>Your Routines</Text>

        {localRoutines.map((routine) => (
          <View key={routine.id} style={styles.routineCard}>
            <View style={styles.routineHeader}>
              <View style={styles.routineInfo}>
                <Text style={styles.routineName}>{routine.name}</Text>
                <Text style={styles.routineTrigger}>"{routine.trigger}"</Text>
              </View>

              <View style={styles.routineActions}>
                <TouchableOpacity 
                  style={styles.toggleBtn}
                  onPress={() => {
                    const updated = localRoutines.map(r => 
                      r.id === routine.id ? { ...r, isActive: !r.isActive } : r
                    );
                    setLocalRoutines(updated);
                    toggleRoutine(routine.id);
                  }}
                >
                  <View style={[styles.toggle, routine.isActive && styles.toggleActive]}>
                    <View style={[styles.toggleDot, routine.isActive && styles.toggleDotActive]} />
                  </View>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.routineStats}>
              <Text style={styles.statText}>{routine.actions.length} actions</Text>
              <Text style={styles.statText}>Run {routine.executionCount} times</Text>
            </View>

            <View style={styles.routineButtons}>
              <TouchableOpacity 
                style={styles.runButton}
                onPress={() => handleExecute(routine)}
              >
                <Ionicons name="play" size={18} color="#0a0a0a" />
                <Text style={styles.runButtonText}>Run Now</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.deleteButton}
                onPress={() => {
                  Alert.alert(
                    'Delete Routine',
                    `Are you sure you want to delete "${routine.name}"?`,
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { 
                        text: 'Delete', 
                        style: 'destructive',
                        onPress: () => {
                          setLocalRoutines(localRoutines.filter(r => r.id !== routine.id));
                          deleteRoutine(routine.id);
                          speak('Routine delete ho gayi.');
                        }
                      },
                    ]
                  );
                }}
              >
                <Ionicons name="trash" size={18} color="#ff6b6b" />
              </TouchableOpacity>
            </View>
          </View>
        ))}

        {/* Scheduled Tasks */}
        <Text style={styles.sectionTitle}>Scheduled Tasks</Text>
        <View style={styles.emptyState}>
          <Ionicons name="calendar" size={48} color="#333" />
          <Text style={styles.emptyText}>No scheduled tasks yet</Text>
          <Text style={styles.emptySubtext}>Tap "Schedule Task" to create one</Text>
        </View>
      </ScrollView>

      {/* Create Routine Modal */}
      <Modal
        visible={showCreateModal}
        transparent
        animationType="slide"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create New Routine</Text>

            <TextInput
              style={styles.modalInput}
              placeholder="Routine Name (e.g., Good Morning)"
              placeholderTextColor="#666"
              value={newRoutineName}
              onChangeText={setNewRoutineName}
            />

            <TextInput
              style={styles.modalInput}
              placeholder="Voice Trigger (e.g., Good Morning)"
              placeholderTextColor="#666"
              value={newTrigger}
              onChangeText={setNewTrigger}
            />

            <Text style={styles.modalLabel}>Actions:</Text>
            {actions.map((action, index) => (
              <View key={index} style={styles.actionChip}>
                <Text style={styles.actionChipText}>{action.type}: {action.data}</Text>
              </View>
            ))}

            <TouchableOpacity 
              style={styles.addActionBtn}
              onPress={() => {
                setActions([...actions, { type: 'OPEN_APP', data: 'youtube' }]);
              }}
            >
              <Ionicons name="add" size={20} color="#00ff88" />
              <Text style={styles.addActionText}>Add Action</Text>
            </TouchableOpacity>

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.cancelBtn]}
                onPress={() => setShowCreateModal(false)}
              >
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.modalBtn, styles.createBtn]}
                onPress={handleCreateRoutine}
              >
                <Text style={styles.createBtnText}>Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Schedule Task Modal */}
      <Modal
        visible={showScheduleModal}
        transparent
        animationType="slide"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Schedule Task</Text>

            <TextInput
              style={styles.modalInput}
              placeholder="Task Name"
              placeholderTextColor="#666"
              value={taskName}
              onChangeText={setTaskName}
            />

            <TextInput
              style={styles.modalInput}
              placeholder="Time (e.g., 2024-01-01 08:00)"
              placeholderTextColor="#666"
              value={taskTime}
              onChangeText={setTaskTime}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.cancelBtn]}
                onPress={() => setShowScheduleModal(false)}
              >
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.modalBtn, styles.createBtn]}
                onPress={handleScheduleTask}
              >
                <Text style={styles.createBtnText}>Schedule</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#888',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  actionBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15,
    borderRadius: 12,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: '#333',
  },
  actionBtnText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
    marginTop: 10,
  },
  routineCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#333',
  },
  routineHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  routineInfo: {
    flex: 1,
  },
  routineName: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  routineTrigger: {
    color: '#00ff88',
    fontSize: 13,
    marginTop: 4,
    fontStyle: 'italic',
  },
  routineActions: {
    flexDirection: 'row',
  },
  toggleBtn: {
    padding: 5,
  },
  toggle: {
    width: 44,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#333',
    justifyContent: 'center',
    paddingHorizontal: 2,
  },
  toggleActive: {
    backgroundColor: '#00ff88',
  },
  toggleDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#666',
  },
  toggleDotActive: {
    backgroundColor: '#0a0a0a',
    transform: [{ translateX: 20 }],
  },
  routineStats: {
    flexDirection: 'row',
    marginTop: 10,
  },
  statText: {
    color: '#666',
    fontSize: 12,
    marginRight: 15,
  },
  routineButtons: {
    flexDirection: 'row',
    marginTop: 12,
  },
  runButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#00ff88',
    paddingVertical: 10,
    borderRadius: 8,
    marginRight: 10,
  },
  runButtonText: {
    color: '#0a0a0a',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 5,
  },
  deleteButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ff6b6b20',
    borderRadius: 8,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    color: '#666',
    fontSize: 16,
    marginTop: 10,
  },
  emptySubtext: {
    color: '#444',
    fontSize: 13,
    marginTop: 5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: '#00000080',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  modalInput: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 15,
    color: '#ffffff',
    fontSize: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#333',
  },
  modalLabel: {
    color: '#888',
    fontSize: 14,
    marginBottom: 8,
  },
  actionChip: {
    backgroundColor: '#00ff8820',
    borderRadius: 8,
    padding: 10,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  actionChipText: {
    color: '#00ff88',
    fontSize: 13,
  },
  addActionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#00ff8830',
    borderStyle: 'dashed',
    marginBottom: 20,
  },
  addActionText: {
    color: '#00ff88',
    fontSize: 14,
    marginLeft: 5,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalBtn: {
    flex: 1,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  cancelBtn: {
    backgroundColor: '#333',
  },
  cancelBtnText: {
    color: '#888',
    fontSize: 16,
    fontWeight: '600',
  },
  createBtn: {
    backgroundColor: '#00ff88',
  },
  createBtnText: {
    color: '#0a0a0a',
    fontSize: 16,
    fontWeight: '600',
  },
});