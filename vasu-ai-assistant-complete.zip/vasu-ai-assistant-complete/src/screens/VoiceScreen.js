import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVoice } from '../context/VoiceContext';
import { useVasu } from '../context/VasuContext';
import VoiceWaveform from '../components/VoiceWaveform';

const { width, height } = Dimensions.get('window');

export default function VoiceScreen() {
  const { 
    transcript, 
    isSpeaking, 
    voiceLevel, 
    isListening,
    startVoiceRecognition, 
    stopVoiceRecognition, 
    speak,
    stopSpeaking 
  } = useVoice();

  const { state } = useVasu();
  const [commandLog, setCommandLog] = useState([]);
  const fadeAnim = useState(new Animated.Value(0))[0];

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleMicPress = () => {
    if (isListening) {
      stopVoiceRecognition();
    } else {
      startVoiceRecognition();
      speak('Haan ji, boliye.');
    }
  };

  const sampleCommands = [
    { icon: 'logo-youtube', text: 'YouTube khol do', color: '#ff0000' },
    { icon: 'call', text: 'Papa ko call karo', color: '#00ff88' },
    { icon: 'chatbubble', text: 'WhatsApp Mom ko message bhejo', color: '#25d366' },
    { icon: 'wifi', text: 'WiFi on karo', color: '#00ccff' },
    { icon: 'flashlight', text: 'Flashlight chalu karo', color: '#ffe66d' },
    { icon: 'musical-notes', text: 'Arijit Singh ka gana bajao', color: '#ff6b6b' },
    { icon: 'search', text: 'Google par pizza recipe search karo', color: '#4285f4' },
    { icon: 'code-slash', text: 'Ek React app banao', color: '#61dafb' },
  ];

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Voice Control</Text>
        <Text style={styles.subtitle}>
          {isListening ? 'Sun raha hoon...' : 'Mic dabayein aur boliye'}
        </Text>
      </View>

      {/* Main Waveform */}
      <View style={styles.waveformSection}>
        <VoiceWaveform level={voiceLevel} isListening={isListening} />

        {transcript ? (
          <View style={styles.transcriptContainer}>
            <Text style={styles.transcriptLabel}>Aapne kaha:</Text>
            <Text style={styles.transcriptText}>{transcript}</Text>
          </View>
        ) : null}

        {state.lastResponse ? (
          <View style={styles.responseContainer}>
            <Text style={styles.responseLabel}>Vasu:</Text>
            <Text style={styles.responseText}>{state.lastResponse}</Text>
          </View>
        ) : null}
      </View>

      {/* Big Mic Button */}
      <View style={styles.micSection}>
        <TouchableOpacity
          style={[styles.micButton, isListening && styles.micButtonActive]}
          onPress={handleMicPress}
          activeOpacity={0.8}
        >
          <Ionicons 
            name={isListening ? "mic" : "mic-outline"} 
            size={60} 
            color={isListening ? "#0a0a0a" : "#00ff88"} 
          />
        </TouchableOpacity>
        <Text style={styles.micStatus}>
          {isListening ? 'Listening...' : 'Tap to Speak'}
        </Text>
        {isSpeaking && (
          <TouchableOpacity style={styles.stopButton} onPress={stopSpeaking}>
            <Text style={styles.stopText}>Stop Speaking</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Sample Commands */}
      <ScrollView style={styles.commandsSection} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>Try These Commands</Text>

        {sampleCommands.map((cmd, index) => (
          <TouchableOpacity
            key={index}
            style={styles.commandCard}
            onPress={() => {
              speak(cmd.text);
              // Simulate command execution
              setCommandLog(prev => [cmd.text, ...prev].slice(0, 10));
            }}
          >
            <View style={[styles.commandIcon, { backgroundColor: cmd.color + '20' }]}>
              <Ionicons name={cmd.icon} size={24} color={cmd.color} />
            </View>
            <Text style={styles.commandText}>{cmd.text}</Text>
            <Ionicons name="play-circle" size={24} color="#00ff88" />
          </TouchableOpacity>
        ))}

        {/* Command History */}
        {commandLog.length > 0 && (
          <View style={styles.historySection}>
            <Text style={styles.sectionTitle}>Recent</Text>
            {commandLog.map((cmd, index) => (
              <View key={index} style={styles.historyItem}>
                <Ionicons name="time-outline" size={16} color="#666" />
                <Text style={styles.historyText}>{cmd}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#888',
    marginTop: 5,
  },
  waveformSection: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  transcriptContainer: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginHorizontal: 20,
    marginTop: 10,
    width: width - 40,
    borderWidth: 1,
    borderColor: '#333',
  },
  transcriptLabel: {
    color: '#888',
    fontSize: 12,
    marginBottom: 5,
  },
  transcriptText: {
    color: '#ffffff',
    fontSize: 16,
  },
  responseContainer: {
    backgroundColor: '#00ff8810',
    borderRadius: 12,
    padding: 15,
    marginHorizontal: 20,
    marginTop: 10,
    width: width - 40,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  responseLabel: {
    color: '#00ff88',
    fontSize: 12,
    marginBottom: 5,
  },
  responseText: {
    color: '#ffffff',
    fontSize: 16,
  },
  micSection: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  micButton: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#1a1a1a',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#00ff88',
    shadowColor: '#00ff88',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  micButtonActive: {
    backgroundColor: '#00ff88',
    borderColor: '#00ff88',
  },
  micStatus: {
    color: '#888',
    fontSize: 16,
    marginTop: 15,
  },
  stopButton: {
    marginTop: 10,
    backgroundColor: '#ff6b6b',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
  },
  stopText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  commandsSection: {
    flex: 1,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
    marginTop: 10,
  },
  commandCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  commandIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  commandText: {
    flex: 1,
    color: '#ffffff',
    fontSize: 14,
    marginLeft: 12,
  },
  historySection: {
    marginTop: 20,
    marginBottom: 30,
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    padding: 10,
    marginBottom: 8,
  },
  historyText: {
    color: '#888',
    fontSize: 14,
    marginLeft: 8,
  },
});