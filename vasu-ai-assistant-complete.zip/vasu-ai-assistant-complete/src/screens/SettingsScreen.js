import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVasu } from '../context/VasuContext';
import { useVoice } from '../context/VoiceContext';
import { useMemory } from '../context/MemoryContext';

export default function SettingsScreen() {
  const { state, setLanguage, setWakeWord, setMode } = useVasu();
  const { language, setLanguage: setVoiceLanguage } = useVoice();
  const { clearAllMemory } = useMemory();

  const [settings, setSettings] = useState({
    alwaysListening: true,
    voiceFeedback: true,
    soundEffects: true,
    hapticFeedback: true,
    autoConfirm: false,
    offlineMode: false,
    accessibilityMode: false,
    highContrast: false,
    largeText: false,
  });

  const toggleSetting = (key) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const languages = [
    { code: 'hi-EN', name: 'Hindi + English', flag: '🇮🇳' },
    { code: 'en-US', name: 'English', flag: '🇺🇸' },
    { code: 'hi-IN', name: 'Hindi', flag: '🇮🇳' },
  ];

  const wakeWords = ['Vasu', 'Hey Vasu', 'OK Vasu', 'Boss'];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Settings</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Language Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Language</Text>
          {languages.map((lang) => (
            <TouchableOpacity
              key={lang.code}
              style={[styles.option, language === lang.code && styles.optionActive]}
              onPress={() => {
                setLanguage(lang.code);
                setVoiceLanguage(lang.code);
              }}
            >
              <Text style={styles.optionText}>{lang.flag} {lang.name}</Text>
              {language === lang.code && (
                <Ionicons name="checkmark" size={20} color="#00ff88" />
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Wake Word Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Wake Word</Text>
          {wakeWords.map((word) => (
            <TouchableOpacity
              key={word}
              style={[styles.option, state.wakeWord === word && styles.optionActive]}
              onPress={() => setWakeWord(word)}
            >
              <Text style={styles.optionText}>"{word}"</Text>
              {state.wakeWord === word && (
                <Ionicons name="checkmark" size={20} color="#00ff88" />
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Voice Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Voice Settings</Text>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="mic" size={20} color="#00ff88" />
              <Text style={styles.toggleText}>Always Listening</Text>
            </View>
            <Switch
              value={settings.alwaysListening}
              onValueChange={() => toggleSetting('alwaysListening')}
              trackColor={{ false: '#333', true: '#00ff8860' }}
              thumbColor={settings.alwaysListening ? '#00ff88' : '#666'}
            />
          </View>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="volume-high" size={20} color="#00ccff" />
              <Text style={styles.toggleText}>Voice Feedback</Text>
            </View>
            <Switch
              value={settings.voiceFeedback}
              onValueChange={() => toggleSetting('voiceFeedback')}
              trackColor={{ false: '#333', true: '#00ccff60' }}
              thumbColor={settings.voiceFeedback ? '#00ccff' : '#666'}
            />
          </View>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="musical-note" size={20} color="#ffe66d" />
              <Text style={styles.toggleText}>Sound Effects</Text>
            </View>
            <Switch
              value={settings.soundEffects}
              onValueChange={() => toggleSetting('soundEffects')}
              trackColor={{ false: '#333', true: '#ffe66d60' }}
              thumbColor={settings.soundEffects ? '#ffe66d' : '#666'}
            />
          </View>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="hand-left" size={20} color="#ff6b6b" />
              <Text style={styles.toggleText}>Haptic Feedback</Text>
            </View>
            <Switch
              value={settings.hapticFeedback}
              onValueChange={() => toggleSetting('hapticFeedback')}
              trackColor={{ false: '#333', true: '#ff6b6b60' }}
              thumbColor={settings.hapticFeedback ? '#ff6b6b' : '#666'}
            />
          </View>
        </View>

        {/* Accessibility */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Accessibility</Text>

          <TouchableOpacity 
            style={styles.option}
            onPress={() => setMode('accessibility')}
          >
            <Ionicons name="accessibility" size={20} color="#a8e6cf" />
            <Text style={styles.optionText}>Accessibility Mode</Text>
            <Ionicons name="chevron-forward" size={20} color="#666" />
          </TouchableOpacity>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="contrast" size={20} color="#ffffff" />
              <Text style={styles.toggleText}>High Contrast</Text>
            </View>
            <Switch
              value={settings.highContrast}
              onValueChange={() => toggleSetting('highContrast')}
              trackColor={{ false: '#333', true: '#ffffff60' }}
              thumbColor={settings.highContrast ? '#ffffff' : '#666'}
            />
          </View>

          <View style={styles.toggleItem}>
            <View style={styles.toggleInfo}>
              <Ionicons name="text" size={20} color="#c7ceea" />
              <Text style={styles.toggleText}>Large Text</Text>
            </View>
            <Switch
              value={settings.largeText}
              onValueChange={() => toggleSetting('largeText')}
              trackColor={{ false: '#333', true: '#c7ceea60' }}
              thumbColor={settings.largeText ? '#c7ceea' : '#666'}
            />
          </View>
        </View>

        {/* Danger Zone */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: '#ff6b6b' }]}>Danger Zone</Text>

          <TouchableOpacity 
            style={[styles.option, { borderColor: '#ff6b6b30' }]}
            onPress={() => {
              Alert.alert(
                'Clear All Data',
                'This will delete all memory, routines, and settings. Are you sure?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { 
                    text: 'Clear Everything', 
                    style: 'destructive',
                    onPress: async () => {
                      await clearAllMemory();
                      Alert.alert('Done', 'All data cleared successfully');
                    }
                  },
                ]
              );
            }}
          >
            <Ionicons name="trash" size={20} color="#ff6b6b" />
            <Text style={[styles.optionText, { color: '#ff6b6b' }]}>Clear All Data</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.option, { borderColor: '#ff6b6b30' }]}
            onPress={() => {
              Alert.alert(
                'Reset to Default',
                'This will reset all settings to default. Continue?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Reset', style: 'destructive' },
                ]
              );
            }}
          >
            <Ionicons name="refresh" size={20} color="#ff6b6b" />
            <Text style={[styles.optionText, { color: '#ff6b6b' }]}>Reset to Default</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Version</Text>
            <Text style={styles.infoValue}>1.0.0</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Build</Text>
            <Text style={styles.infoValue}>2024.01.01</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>AI Engine</Text>
            <Text style={styles.infoValue}>GPT-4 + Whisper</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    marginBottom: 20,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#888',
    marginBottom: 10,
    marginTop: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1a1a1a',
    borderRadius: 10,
    padding: 15,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  optionActive: {
    borderColor: '#00ff88',
    backgroundColor: '#00ff8810',
  },
  optionText: {
    color: '#ffffff',
    fontSize: 15,
  },
  toggleItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1a1a1a',
    borderRadius: 10,
    padding: 15,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  toggleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  toggleText: {
    color: '#ffffff',
    fontSize: 15,
    marginLeft: 12,
  },
  infoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#222',
  },
  infoLabel: {
    color: '#666',
    fontSize: 14,
  },
  infoValue: {
    color: '#ffffff',
    fontSize: 14,
  },
});