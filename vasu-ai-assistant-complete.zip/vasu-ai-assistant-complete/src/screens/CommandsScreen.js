import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVoice } from '../context/VoiceContext';

const { width } = Dimensions.get('window');

const COMMAND_CATEGORIES = [
  {
    title: 'App Control',
    icon: 'apps',
    color: '#00ff88',
    commands: [
      { cmd: 'Open [App Name]', desc: 'Koi bhi app kholein', example: 'Open YouTube' },
      { cmd: 'Close [App Name]', desc: 'App band karein', example: 'Close Chrome' },
      { cmd: 'Switch to [App]', desc: 'App switch karein', example: 'Switch to WhatsApp' },
    ]
  },
  {
    title: 'Communication',
    icon: 'chatbubbles',
    color: '#00ccff',
    commands: [
      { cmd: 'Call [Name]', desc: 'Phone call karein', example: 'Call Papa' },
      { cmd: 'Send WhatsApp to [Name]: [Message]', desc: 'WhatsApp message', example: 'Send WhatsApp to Mom: Hello' },
      { cmd: 'Send SMS to [Number]: [Message]', desc: 'SMS bhejein', example: 'Send SMS to 9876543210: Hi' },
      { cmd: 'Email [Address]: [Subject]', desc: 'Email bhejein', example: 'Email boss@company.com: Report' },
    ]
  },
  {
    title: 'Settings',
    icon: 'settings',
    color: '#ff6b6b',
    commands: [
      { cmd: 'Turn on/off WiFi', desc: 'WiFi control', example: 'WiFi on karo' },
      { cmd: 'Turn on/off Bluetooth', desc: 'Bluetooth control', example: 'Bluetooth off karo' },
      { cmd: 'Flashlight on/off', desc: 'Torch control', example: 'Flashlight chalu karo' },
      { cmd: 'Volume [0-100]', desc: 'Volume set karein', example: 'Volume 80' },
      { cmd: 'Brightness [0-100]', desc: 'Brightness set karein', example: 'Brightness 70' },
      { cmd: 'Do Not Disturb on/off', desc: 'DND mode', example: 'Do Not Disturb on' },
    ]
  },
  {
    title: 'Search & Web',
    icon: 'globe',
    color: '#ffe66d',
    commands: [
      { cmd: 'Search [Query]', desc: 'Google search', example: 'Search best restaurants' },
      { cmd: 'YouTube [Query]', desc: 'YouTube search', example: 'YouTube funny videos' },
      { cmd: 'Open [Website]', desc: 'Website kholein', example: 'Open google.com' },
    ]
  },
  {
    title: 'Media',
    icon: 'musical-notes',
    color: '#a8e6cf',
    commands: [
      { cmd: 'Play [Song/Artist]', desc: 'Music play karein', example: 'Play Arijit Singh' },
      { cmd: 'Pause/Stop', desc: 'Music rokein', example: 'Pause' },
      { cmd: 'Next/Previous', desc: 'Track change karein', example: 'Next song' },
      { cmd: 'Volume up/down', desc: 'Volume adjust karein', example: 'Volume up' },
    ]
  },
  {
    title: 'AI Coding',
    icon: 'code-slash',
    color: '#ff8b94',
    commands: [
      { cmd: 'Create [Type] app', desc: 'App banaein', example: 'Create React app' },
      { cmd: 'Write [Language] code', desc: 'Code likhein', example: 'Write Python script' },
      { cmd: 'Debug this code', desc: 'Code debug karein', example: 'Debug my function' },
      { cmd: 'Build and deploy', desc: 'Build & deploy karein', example: 'Build and deploy to Vercel' },
    ]
  },
  {
    title: 'Automation',
    icon: 'repeat',
    color: '#c7ceea',
    commands: [
      { cmd: 'Create routine [Name]', desc: 'Routine banayein', example: 'Create routine Good Morning' },
      { cmd: 'Schedule [Task] at [Time]', desc: 'Task schedule karein', example: 'Schedule reminder at 8 AM' },
      { cmd: 'Run [Routine Name]', desc: 'Routine chalayein', example: 'Run Good Morning' },
    ]
  },
  {
    title: 'Learning',
    icon: 'school',
    color: '#ffd93d',
    commands: [
      { cmd: 'Teach me [Topic]', desc: 'Kuch sikhein', example: 'Teach me Spanish numbers' },
      { cmd: 'Quiz me on [Topic]', desc: 'Test lein', example: 'Quiz me on capitals' },
      { cmd: 'Revision', desc: 'Revision karein', example: 'Start revision' },
    ]
  },
];

export default function CommandsScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategory, setExpandedCategory] = useState(null);
  const { speak } = useVoice();

  const filteredCategories = COMMAND_CATEGORIES.filter(cat => 
    cat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cat.commands.some(cmd => 
      cmd.cmd.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cmd.desc.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>All Commands</Text>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#666" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search commands..."
            placeholderTextColor="#666"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {filteredCategories.map((category, index) => (
          <View key={index} style={styles.categoryContainer}>
            <TouchableOpacity
              style={styles.categoryHeader}
              onPress={() => setExpandedCategory(
                expandedCategory === index ? null : index
              )}
            >
              <View style={[styles.categoryIcon, { backgroundColor: category.color + '20' }]}>
                <Ionicons name={category.icon} size={24} color={category.color} />
              </View>
              <Text style={styles.categoryTitle}>{category.title}</Text>
              <Ionicons 
                name={expandedCategory === index ? "chevron-up" : "chevron-down"} 
                size={20} 
                color="#666" 
              />
            </TouchableOpacity>

            {expandedCategory === index && (
              <View style={styles.commandsList}>
                {category.commands.map((cmd, cmdIndex) => (
                  <TouchableOpacity
                    key={cmdIndex}
                    style={styles.commandItem}
                    onPress={() => speak(`${cmd.cmd}. Example: ${cmd.example}`)}
                  >
                    <View style={styles.commandHeader}>
                      <Text style={styles.commandName}>{cmd.cmd}</Text>
                      <Ionicons name="play-circle" size={20} color={category.color} />
                    </View>
                    <Text style={styles.commandDesc}>{cmd.desc}</Text>
                    <View style={styles.exampleContainer}>
                      <Text style={styles.exampleLabel}>Example:</Text>
                      <Text style={styles.exampleText}>{cmd.example}</Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  searchInput: {
    flex: 1,
    color: '#ffffff',
    fontSize: 16,
    marginLeft: 10,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  categoryContainer: {
    marginBottom: 10,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    borderWidth: 1,
    borderColor: '#333',
  },
  categoryIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryTitle: {
    flex: 1,
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 12,
  },
  commandsList: {
    paddingLeft: 20,
    paddingTop: 10,
  },
  commandItem: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 15,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  commandHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  commandName: {
    color: '#00ff88',
    fontSize: 15,
    fontWeight: '600',
  },
  commandDesc: {
    color: '#888',
    fontSize: 13,
    marginBottom: 8,
  },
  exampleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  exampleLabel: {
    color: '#666',
    fontSize: 12,
    marginRight: 5,
  },
  exampleText: {
    color: '#ffe66d',
    fontSize: 12,
    fontStyle: 'italic',
  },
});