import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ProgressBarAndroid,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMemory } from '../context/MemoryContext';
import { useVoice } from '../context/VoiceContext';

export default function MemoryScreen() {
  const { 
    learningItems, 
    addLearningItem, 
    reviewItem, 
    getDueItems,
    getMemoryStats,
    clearAllMemory,
    userHabits,
  } = useMemory();

  const { speak } = useVoice();
  const [stats, setStats] = useState({});
  const [dueItems, setDueItems] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItem, setNewItem] = useState('');
  const [activeTab, setActiveTab] = useState('due'); // due, all, habits

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const memoryStats = await getMemoryStats();
    setStats(memoryStats);

    const items = await getDueItems();
    setDueItems(items);
  };

  const handleAddItem = async () => {
    if (!newItem.trim()) return;

    await addLearningItem(newItem);
    setNewItem('');
    setShowAddModal(false);
    speak('Naya item add ho gaya. Main aapko revise karwaunga.');
    loadData();
  };

  const handleReview = async (itemId, confidence) => {
    await reviewItem(itemId, confidence);
    speak(confidence > 80 ? 'Bahut badhiya! Yaad hai.' : 'Koi baat nahi, phir se dekhte hain.');
    loadData();
  };

  const handleClearMemory = () => {
    Alert.alert(
      'Clear All Memory',
      'Are you sure? This will delete all learning data.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: async () => {
            await clearAllMemory();
            speak('Saari memory clear ho gayi.');
            loadData();
          }
        },
      ]
    );
  };

  const renderDueItems = () => (
    <View>
      {dueItems.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="checkmark-circle" size={48} color="#00ff88" />
          <Text style={styles.emptyTitle}>Sab kuch yaad hai!</Text>
          <Text style={styles.emptyText}>Koi revision pending nahi hai.</Text>
        </View>
      ) : (
        dueItems.map((item) => (
          <View key={item.id} style={styles.reviewCard}>
            <View style={styles.reviewHeader}>
              <Text style={styles.reviewContent}>{item.content}</Text>
              <View style={styles.stageBadge}>
                <Text style={styles.stageText}>Stage {item.stage + 1}</Text>
              </View>
            </View>

            <View style={styles.reviewActions}>
              <TouchableOpacity 
                style={[styles.reviewBtn, { backgroundColor: '#ff6b6b' }]}
                onPress={() => handleReview(item.id, 30)}
              >
                <Text style={styles.reviewBtnText}>Hard (30%)</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.reviewBtn, { backgroundColor: '#ffe66d' }]}
                onPress={() => handleReview(item.id, 60)}
              >
                <Text style={styles.reviewBtnText}>Good (60%)</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.reviewBtn, { backgroundColor: '#00ff88' }]}
                onPress={() => handleReview(item.id, 90)}
              >
                <Text style={styles.reviewBtnText}>Easy (90%)</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))
      )}
    </View>
  );

  const renderAllItems = () => (
    <View>
      {learningItems.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="book" size={48} color="#666" />
          <Text style={styles.emptyTitle}>Kuch bhi add nahi kiya</Text>
          <Text style={styles.emptyText}>"Teach me" bolke kuch sikhein!</Text>
        </View>
      ) : (
        learningItems.map((item) => (
          <View key={item.id} style={styles.itemCard}>
            <View style={styles.itemHeader}>
              <Text style={styles.itemContent}>{item.content}</Text>
              {item.isMastered && (
                <Ionicons name="checkmark-circle" size={20} color="#00ff88" />
              )}
            </View>
            <View style={styles.itemStats}>
              <Text style={styles.itemStat}>Reviews: {item.reviewCount}</Text>
              <Text style={styles.itemStat}>Confidence: {item.confidence}%</Text>
              <Text style={styles.itemStat}>Stage: {item.stage + 1}/7</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${(item.stage / 6) * 100}%` }]} />
            </View>
          </View>
        ))
      )}
    </View>
  );

  const renderHabits = () => (
    <View>
      {Object.keys(userHabits).length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="trending-up" size={48} color="#666" />
          <Text style={styles.emptyTitle}>Abhi habits track nahi hui</Text>
          <Text style={styles.emptyText}>Vasu aapki habits seekh raha hai...</Text>
        </View>
      ) : (
        Object.entries(userHabits).map(([action, habit]) => (
          <View key={action} style={styles.habitCard}>
            <View style={styles.habitHeader}>
              <Ionicons name="time" size={20} color="#00ff88" />
              <Text style={styles.habitAction}>{action}</Text>
              <Text style={styles.habitCount}>{habit.count}x</Text>
            </View>
            <Text style={styles.habitContext}>Last: {habit.contexts[habit.contexts.length - 1]}</Text>
          </View>
        ))
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Memory & Learning</Text>
        <Text style={styles.subtitle}>Faster Than Brain Mode</Text>
      </View>

      {/* Stats Cards */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{stats.totalLearningItems || 0}</Text>
          <Text style={styles.statLabel}>Items</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{stats.masteredItems || 0}</Text>
          <Text style={styles.statLabel}>Mastered</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{stats.dueItems || 0}</Text>
          <Text style={styles.statLabel}>Due Now</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{stats.habitsTracked || 0}</Text>
          <Text style={styles.statLabel}>Habits</Text>
        </View>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        {['due', 'all', 'habits'].map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && styles.tabActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {activeTab === 'due' && renderDueItems()}
        {activeTab === 'all' && renderAllItems()}
        {activeTab === 'habits' && renderHabits()}
      </ScrollView>

      {/* Floating Action Button */}
      <TouchableOpacity 
        style={styles.fab}
        onPress={() => setShowAddModal(true)}
      >
        <Ionicons name="add" size={28} color="#0a0a0a" />
      </TouchableOpacity>

      {/* Add Item Modal */}
      {showAddModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Learning Item</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Kya sikhna hai? (e.g., Spanish Numbers)"
              placeholderTextColor="#666"
              value={newItem}
              onChangeText={setNewItem}
              multiline
              numberOfLines={3}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.cancelBtn]}
                onPress={() => setShowAddModal(false)}
              >
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.createBtn]}
                onPress={handleAddItem}
              >
                <Text style={styles.createBtnText}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 16,
    color: '#00ff88',
    marginTop: 5,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    alignItems: 'center',
    width: '23%',
    borderWidth: 1,
    borderColor: '#333',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00ff88',
  },
  statLabel: {
    fontSize: 12,
    color: '#888',
    marginTop: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 5,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
  },
  tabActive: {
    backgroundColor: '#00ff8820',
    borderColor: '#00ff88',
  },
  tabText: {
    color: '#888',
    fontSize: 14,
    fontWeight: '600',
  },
  tabTextActive: {
    color: '#00ff88',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 15,
  },
  emptyText: {
    color: '#666',
    fontSize: 14,
    marginTop: 5,
  },
  reviewCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#00ff8830',
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 15,
  },
  reviewContent: {
    flex: 1,
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '500',
  },
  stageBadge: {
    backgroundColor: '#00ff8820',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  stageText: {
    color: '#00ff88',
    fontSize: 11,
    fontWeight: '600',
  },
  reviewActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  reviewBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  reviewBtnText: {
    color: '#0a0a0a',
    fontSize: 12,
    fontWeight: '600',
  },
  itemCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  itemContent: {
    flex: 1,
    color: '#ffffff',
    fontSize: 15,
  },
  itemStats: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  itemStat: {
    color: '#666',
    fontSize: 12,
    marginRight: 15,
  },
  progressBar: {
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#00ff88',
    borderRadius: 2,
  },
  habitCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  habitHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  habitAction: {
    flex: 1,
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '500',
    marginLeft: 10,
  },
  habitCount: {
    color: '#00ff88',
    fontSize: 14,
    fontWeight: 'bold',
  },
  habitContext: {
    color: '#666',
    fontSize: 13,
    marginLeft: 30,
  },
  fab: {
    position: 'absolute',
    bottom: 30,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#00ff88',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#00ff88',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#00000080',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 20,
    width: '100%',
    borderWidth: 1,
    borderColor: '#333',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
  },
  modalInput: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 15,
    color: '#ffffff',
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#333',
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalBtn: {
    flex: 1,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  cancelBtn: {
    backgroundColor: '#333',
  },
  cancelBtnText: {
    color: '#888',
    fontSize: 16,
    fontWeight: '600',
  },
  createBtn: {
    backgroundColor: '#00ff88',
  },
  createBtnText: {
    color: '#0a0a0a',
    fontSize: 16,
    fontWeight: '600',
  },
});