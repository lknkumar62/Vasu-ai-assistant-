import { useState, useCallback, useEffect } from 'react';
import { useMemory } from '../context/MemoryContext';
import { useVoice } from '../context/VoiceContext';

// Spaced Repetition Algorithm (SM-2 variant)
const SRS_INTERVALS = [2, 10, 60, 240, 1440, 4320, 10080]; // minutes

export function useLearning() {
  const { 
    learningItems, 
    addLearningItem, 
    reviewItem, 
    getDueItems,
    getMemoryStats,
  } = useMemory();

  const { speak } = useVoice();

  const [currentItem, setCurrentItem] = useState(null);
  const [isReviewing, setIsReviewing] = useState(false);
  const [sessionStats, setSessionStats] = useState({
    reviewed: 0,
    correct: 0,
    streak: 0,
  });

  // Start a learning session
  const startSession = useCallback(async (topic = null) => {
    const due = await getDueItems();

    if (due.length === 0) {
      speak('Koi revision pending nahi hai! Aap great ho!');
      return { success: false, message: 'No items due' };
    }

    setIsReviewing(true);
    setCurrentItem(due[0]);
    setSessionStats({ reviewed: 0, correct: 0, streak: 0 });

    speak(`Learning session shuru! ${due.length} items pending hain.`);

    return { success: true, totalItems: due.length };
  }, [getDueItems, speak]);

  // Review current item
  const reviewCurrentItem = useCallback(async (confidence) => {
    if (!currentItem) return;

    await reviewItem(currentItem.id, confidence);

    setSessionStats(prev => ({
      reviewed: prev.reviewed + 1,
      correct: confidence >= 60 ? prev.correct + 1 : prev.correct,
      streak: confidence >= 60 ? prev.streak + 1 : 0,
    }));

    // Get next item
    const due = await getDueItems();
    if (due.length > 0) {
      setCurrentItem(due[0]);
      speak(due[0].content);
    } else {
      setCurrentItem(null);
      setIsReviewing(false);
      speak(`Session complete! ${sessionStats.reviewed + 1} items review kiye. Bahut badhiya!`);
    }
  }, [currentItem, reviewItem, getDueItems, speak, sessionStats.reviewed]);

  // Add new learning content
  const addContent = useCallback(async (content, category = 'general') => {
    const id = await addLearningItem({
      content,
      category,
      createdAt: Date.now(),
    });

    speak('Naya item add ho gaya! Main aapko revise karwaunga.');
    return { success: true, id };
  }, [addLearningItem, speak]);

  // Quick review - show item and get immediate feedback
  const quickReview = useCallback(async (itemId) => {
    const item = learningItems.find(i => i.id === itemId);
    if (!item) return { success: false, error: 'Item not found' };

    speak(item.content);
    return { success: true, item };
  }, [learningItems, speak]);

  // Get learning statistics
  const getStats = useCallback(async () => {
    const stats = await getMemoryStats();
    return {
      ...stats,
      sessionStats,
      isReviewing,
    };
  }, [getMemoryStats, sessionStats, isReviewing]);

  // Auto-schedule reminders for due items
  useEffect(() => {
    const checkDueItems = async () => {
      const due = await getDueItems();
      if (due.length > 0 && !isReviewing) {
        speak(`${due.length} items revision ke liye ready hain!`);
      }
    };

    const interval = setInterval(checkDueItems, 30 * 60 * 1000); // Check every 30 minutes
    return () => clearInterval(interval);
  }, [getDueItems, isReviewing, speak]);

  return {
    currentItem,
    isReviewing,
    sessionStats,
    learningItems,
    startSession,
    reviewCurrentItem,
    addContent,
    quickReview,
    getStats,
  };
}