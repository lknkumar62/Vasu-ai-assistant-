import { useState, useCallback } from 'react';
import { useAutomation as useAutomationContext } from '../context/AutomationContext';
import { useVoice } from '../context/VoiceContext';

export function useAutomation() {
  const {
    routines,
    createRoutine,
    executeRoutine,
    scheduleTask,
    cancelTask,
    deleteRoutine,
    toggleRoutine,
  } = useAutomationContext();

  const { speak } = useVoice();

  const [isCreating, setIsCreating] = useState(false);
  const [activeWorkflow, setActiveWorkflow] = useState(null);

  // Create a routine from voice command
  const createRoutineFromVoice = useCallback(async (name, trigger, actions) => {
    try {
      setIsCreating(true);

      const id = await createRoutine(name, trigger, actions);

      speak(`Routine "${name}" create ho gayi! Trigger: "${trigger}"`);

      setIsCreating(false);
      return { success: true, id };
    } catch (error) {
      speak('Routine create karne mein error aaya.');
      setIsCreating(false);
      return { success: false, error: error.message };
    }
  }, [createRoutine, speak]);

  // Execute routine by name
  const executeRoutineByName = useCallback(async (name) => {
    try {
      const routine = routines.find(r => 
        r.name.toLowerCase() === name.toLowerCase() ||
        r.trigger.toLowerCase() === name.toLowerCase()
      );

      if (!routine) {
        speak(`Routine "${name}" nahi mili.`);
        return { success: false, error: 'Routine not found' };
      }

      speak(`Routine "${routine.name}" chala raha hoon...`);
      const success = await executeRoutine(routine.id);

      if (success) {
        speak(`Routine "${routine.name}" complete!`);
      }

      return { success };
    } catch (error) {
      speak('Routine execute karne mein error.');
      return { success: false, error: error.message };
    }
  }, [routines, executeRoutine, speak]);

  // Schedule a task
  const scheduleTaskFromVoice = useCallback(async (name, time, actions = []) => {
    try {
      const id = await scheduleTask({
        name,
        time,
        actions,
      });

      const timeStr = new Date(time).toLocaleString();
      speak(`Task "${name}" ${timeStr} ke liye schedule ho gayi!`);

      return { success: true, id };
    } catch (error) {
      speak('Task schedule karne mein error.');
      return { success: false, error: error.message };
    }
  }, [scheduleTask, speak]);

  // Toggle routine active status
  const toggleRoutineByName = useCallback(async (name) => {
    const routine = routines.find(r => r.name.toLowerCase() === name.toLowerCase());
    if (!routine) {
      return { success: false, error: 'Routine not found' };
    }

    await toggleRoutine(routine.id);
    const status = routine.isActive ? 'off' : 'on';
    speak(`Routine "${name}" ${status} kar di.`);

    return { success: true };
  }, [routines, toggleRoutine, speak]);

  // Delete routine by name
  const deleteRoutineByName = useCallback(async (name) => {
    const routine = routines.find(r => r.name.toLowerCase() === name.toLowerCase());
    if (!routine) {
      return { success: false, error: 'Routine not found' };
    }

    await deleteRoutine(routine.id);
    speak(`Routine "${name}" delete ho gayi.`);

    return { success: true };
  }, [routines, deleteRoutine, speak]);

  // Get routine suggestions based on time
  const getRoutineSuggestions = useCallback(() => {
    const hour = new Date().getHours();
    const suggestions = [];

    if (hour >= 6 && hour <= 9) {
      suggestions.push('Good Morning');
    }
    if (hour >= 12 && hour <= 14) {
      suggestions.push('Lunch Break');
    }
    if (hour >= 18 && hour <= 21) {
      suggestions.push('Movie Night');
    }
    if (hour >= 22 || hour <= 5) {
      suggestions.push('Sleep Mode');
    }

    return suggestions;
  }, []);

  return {
    routines,
    isCreating,
    activeWorkflow,
    createRoutineFromVoice,
    executeRoutineByName,
    scheduleTaskFromVoice,
    toggleRoutineByName,
    deleteRoutineByName,
    getRoutineSuggestions,
  };
}