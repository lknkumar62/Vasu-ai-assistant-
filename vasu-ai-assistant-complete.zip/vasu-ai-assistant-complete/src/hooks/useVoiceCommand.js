import { useState, useCallback, useRef } from 'react';
import { useVasu } from '../context/VasuContext';
import { useVoice } from '../context/VoiceContext';
import { useSecurity } from '../context/SecurityContext';
import aiService from '../services/aiService';
import deviceService from '../services/deviceService';

export function useVoiceCommand() {
  const { state, setProcessing, setReady, setCommand, setResponse, addNotification } = useVasu();
  const { speak, stopSpeaking } = useVoice();
  const { requiresConfirmation, isAuthenticated } = useSecurity();

  const [isExecuting, setIsExecuting] = useState(false);
  const [lastError, setLastError] = useState(null);
  const commandQueue = useRef([]);

  // Execute a single command
  const executeCommand = useCallback(async (commandText) => {
    try {
      setIsExecuting(true);
      setProcessing();
      setCommand(commandText);
      setLastError(null);

      // Check authentication for sensitive commands
      const riskLevel = requiresConfirmation(commandText);
      if (riskLevel && !isAuthenticated) {
        speak('Security alert! Pehle authenticate karein.');
        setReady();
        setIsExecuting(false);
        return { success: false, requiresAuth: true };
      }

      // Confirm risky actions
      if (riskLevel === 'HIGH' || riskLevel === 'CRITICAL') {
        speak(`Warning: Yeh ${riskLevel.toLowerCase()} risk wali command hai. Confirm karein?`);
        // In real implementation, wait for user confirmation
      }

      // Process with AI
      const aiResponse = await aiService.processCommand(commandText, state.language);

      if (!aiResponse.success) {
        throw new Error(aiResponse.response || 'Command process nahi ho paya');
      }

      // Execute based on intent
      const result = await executeIntent(aiResponse);

      // Set response
      setResponse(aiResponse.response || 'Command execute ho gayi!');
      speak(aiResponse.response || 'Done!');

      addNotification({
        type: 'command',
        message: commandText,
        response: aiResponse.response,
        timestamp: Date.now(),
      });

      return { success: true, result };
    } catch (error) {
      console.error('Command execution error:', error);
      setLastError(error.message);
      speak('Error: ' + error.message);
      return { success: false, error: error.message };
    } finally {
      setReady();
      setIsExecuting(false);
    }
  }, [state.language, isAuthenticated, requiresConfirmation, setProcessing, setReady, setCommand, setResponse, addNotification, speak]);

  // Execute intent-based actions
  const executeIntent = async (aiResponse) => {
    const { intent, action, params } = aiResponse;

    switch (intent) {
      case 'OPEN_APP':
        return await deviceService.openApp(params.app || action);

      case 'CALL':
        return await deviceService.makeCall(params.number || action);

      case 'MESSAGE':
        if (params.platform === 'whatsapp') {
          return await deviceService.sendWhatsApp(params.number, params.message);
        }
        return await deviceService.sendSMS(params.number, params.message);

      case 'EMAIL':
        return await deviceService.sendEmail(params.to, params.subject, params.body);

      case 'SEARCH':
        if (params.engine === 'youtube') {
          return await deviceService.searchYouTube(params.query);
        }
        return await deviceService.searchGoogle(params.query);

      case 'WEB':
        return await deviceService.openURL(params.url);

      case 'SETTINGS':
        return await deviceService.toggleSetting(params.setting, params.value);

      case 'CODE':
        const codeResult = await aiService.generateCode(params.description, params.language);
        return codeResult;

      case 'DEPLOY':
        const deployResult = await aiService.deployProject(params.platform, params.path, params.name);
        return deployResult;

      case 'SYSTEM':
        return await aiService.executeSystemCommand(params.command);

      default:
        return { success: true, message: 'Query processed' };
    }
  };

  // Execute multiple commands in sequence
  const executeSequence = useCallback(async (commands) => {
    const results = [];
    for (const command of commands) {
      const result = await executeCommand(command);
      results.push(result);
      if (!result.success) break;
    }
    return results;
  }, [executeCommand]);

  // Queue command for later execution
  const queueCommand = useCallback((command) => {
    commandQueue.current.push(command);
    return { success: true, queueLength: commandQueue.current.length };
  }, []);

  // Execute all queued commands
  const executeQueue = useCallback(async () => {
    const commands = [...commandQueue.current];
    commandQueue.current = [];
    return await executeSequence(commands);
  }, [executeSequence]);

  return {
    executeCommand,
    executeSequence,
    queueCommand,
    executeQueue,
    isExecuting,
    lastError,
    commandQueue: commandQueue.current,
  };
}