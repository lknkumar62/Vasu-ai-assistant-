// Natural Language Command Parser for Vasu AI
// Converts voice commands to structured intents

class CommandParser {
  constructor() {
    this.patterns = this.initializePatterns();
  }

  initializePatterns() {
    return {
      // App Control Patterns
      openApp: {
        patterns: [
          /(?:open|launch|start|khol|chalu)\s+(.+)/i,
          /(.+)\s+(?:khol|chalu|open)\s+kar/i,
        ],
        intent: 'OPEN_APP',
        extractParams: (matches) => ({ app: matches[1].trim() }),
      },

      // Call Patterns
      call: {
        patterns: [
          /(?:call|phone|dial|call karo)\s+(?:to\s+)?(.+)/i,
          /(.+)\s+ko\s+(?:call|phone)\s+kar/i,
        ],
        intent: 'CALL',
        extractParams: (matches) => ({ contact: matches[1].trim() }),
      },

      // Message Patterns
      message: {
        patterns: [
          /(?:send|message|text|whatsapp|sms)\s+(?:to\s+)?(.+?):\s*(.+)/i,
          /(.+)\s+ko\s+message\s+bhejo:\s*(.+)/i,
        ],
        intent: 'MESSAGE',
        extractParams: (matches) => ({
          contact: matches[1].trim(),
          message: matches[2].trim(),
          platform: matches[0].toLowerCase().includes('whatsapp') ? 'whatsapp' : 'sms',
        }),
      },

      // Settings Patterns
      settings: {
        patterns: [
          /(?:turn|toggle|switch)\s+(?:on|off|enable|disable)\s*(.+)/i,
          /(.+)\s+(?:on|off|enable|disable)\s+kar/i,
          /(?:wifi|bluetooth|flashlight|torch|data|location|airplane)\s+(?:on|off)/i,
        ],
        intent: 'SETTINGS',
        extractParams: (matches, fullCommand) => {
          const setting = matches[1] ? matches[1].trim() : this.extractSetting(fullCommand);
          const value = fullCommand.toLowerCase().includes('on') || 
                       fullCommand.toLowerCase().includes('enable') ||
                       fullCommand.toLowerCase().includes('chalu');
          return { setting, value };
        },
      },

      // Search Patterns
      search: {
        patterns: [
          /(?:search|google|find|dhundo|dikhao)\s+(?:for\s+)?(.+)/i,
          /(.+)\s+(?:search|google)\s+kar/i,
          /(?:youtube|yt)\s+(?:search|find)\s+(.+)/i,
        ],
        intent: 'SEARCH',
        extractParams: (matches, fullCommand) => ({
          query: matches[1].trim(),
          engine: fullCommand.toLowerCase().includes('youtube') ? 'youtube' : 'google',
        }),
      },

      // Media Patterns
      media: {
        patterns: [
          /(?:play|bajao|chala|start)\s+(.+)/i,
          /(?:pause|stop|rok)\s+(?:music|song|video|media)/i,
          /(?:next|previous|agla|pehla)\s+(?:song|track|video)/i,
          /(?:volume|sound)\s+(?:up|down|badhao|kam)/i,
        ],
        intent: 'MEDIA',
        extractParams: (matches, fullCommand) => {
          const action = this.extractMediaAction(fullCommand);
          return {
            action,
            media: matches[1] ? matches[1].trim() : null,
          };
        },
      },

      // Code Patterns
      code: {
        patterns: [
          /(?:create|build|make|banao|banao)\s+(?:a|an|ek)\s+(.+)\s+(?:app|website|script|program)/i,
          /(?:write|code|program)\s+(.+)/i,
          /(?:debug|fix|repair)\s+(?:this|ye)\s+(.+)/i,
          /(?:deploy|host|publish|live)\s+(?:this|ye)\s+(.+)/i,
        ],
        intent: 'CODE',
        extractParams: (matches, fullCommand) => ({
          description: matches[1] ? matches[1].trim() : fullCommand,
          action: this.extractCodeAction(fullCommand),
          language: this.extractLanguage(fullCommand),
        }),
      },

      // Learning Patterns
      learning: {
        patterns: [
          /(?:teach|sikhao|learn|study|padh)\s+(?:me\s+)?(.+)/i,
          /(?:quiz|test|exam)\s+(?:me\s+)?(?:on\s+)?(.+)/i,
          /(?:revise|revision|dohrai|repeat)\s+(.+)/i,
          /(?:remember|yaad|save)\s+(.+)/i,
        ],
        intent: 'LEARN',
        extractParams: (matches, fullCommand) => ({
          topic: matches[1] ? matches[1].trim() : fullCommand,
          action: this.extractLearningAction(fullCommand),
        }),
      },

      // Automation Patterns
      automation: {
        patterns: [
          /(?:create|make|banao)\s+(?:a|an|ek)\s+routine/i,
          /(?:schedule|set|lagao)\s+(?:a|an|ek)\s+(?:reminder|alarm|task)/i,
          /(?:run|execute|chalao)\s+routine\s+(.+)/i,
          /(?:good morning|good night|work mode|movie night)/i,
        ],
        intent: 'AUTOMATION',
        extractParams: (matches, fullCommand) => ({
          routine: matches[1] ? matches[1].trim() : this.extractRoutineName(fullCommand),
          action: this.extractAutomationAction(fullCommand),
        }),
      },

      // Query Patterns (fallback)
      query: {
        patterns: [
          /(?:what|who|when|where|why|how|kya|kaun|kab|kahan|kyon|kaise)\s+(.+)/i,
          /(?:tell|batao|explain|samjhao)\s+(.+)/i,
        ],
        intent: 'QUERY',
        extractParams: (matches) => ({ query: matches[1] ? matches[1].trim() : matches[0] }),
      },
    };
  }

  // Extract setting from command
  extractSetting(command) {
    const settings = ['wifi', 'bluetooth', 'flashlight', 'torch', 'data', 'location', 
                      'airplane', 'hotspot', 'rotation', 'sync', 'sound', 'notification'];
    const lower = command.toLowerCase();
    return settings.find(s => lower.includes(s)) || 'unknown';
  }

  // Extract media action
  extractMediaAction(command) {
    if (command.match(/play|bajao|chala|start/)) return 'play';
    if (command.match(/pause|stop|rok/)) return 'pause';
    if (command.match(/next|agla/)) return 'next';
    if (command.match(/previous|pehla|back/)) return 'previous';
    if (command.match(/volume up|sound badhao/)) return 'volume_up';
    if (command.match(/volume down|sound kam/)) return 'volume_down';
    return 'play';
  }

  // Extract code action
  extractCodeAction(command) {
    if (command.match(/create|build|make|banao|banao/)) return 'create';
    if (command.match(/write|code|program/)) return 'write';
    if (command.match(/debug|fix|repair/)) return 'debug';
    if (command.match(/deploy|host|publish|live/)) return 'deploy';
    return 'create';
  }

  // Extract programming language
  extractLanguage(command) {
    const languages = {
      'react': 'javascript',
      'node': 'javascript',
      'python': 'python',
      'flutter': 'dart',
      'html': 'html',
      'css': 'css',
      'java': 'java',
      'kotlin': 'kotlin',
      'swift': 'swift',
    };
    const lower = command.toLowerCase();
    return Object.entries(languages).find(([key]) => lower.includes(key))?.[1] || 'javascript';
  }

  // Extract learning action
  extractLearningAction(command) {
    if (command.match(/teach|sikhao|learn|study|padh/)) return 'teach';
    if (command.match(/quiz|test|exam/)) return 'quiz';
    if (command.match(/revise|revision|dohrai|repeat/)) return 'revise';
    if (command.match(/remember|yaad|save/)) return 'remember';
    return 'teach';
  }

  // Extract routine name
  extractRoutineName(command) {
    const routines = ['good morning', 'good night', 'work mode', 'movie night', 
                     'lunch break', 'sleep mode', 'focus mode'];
    const lower = command.toLowerCase();
    return routines.find(r => lower.includes(r)) || 'custom';
  }

  // Extract automation action
  extractAutomationAction(command) {
    if (command.match(/create|make|banao/)) return 'create';
    if (command.match(/schedule|set|lagao/)) return 'schedule';
    if (command.match(/run|execute|chalao/)) return 'run';
    return 'run';
  }

  // Main parse function
  parse(command) {
    if (!command || typeof command !== 'string') {
      return {
        intent: 'UNKNOWN',
        confidence: 0,
        params: {},
        originalCommand: command,
      };
    }

    const cleanCommand = command.trim().toLowerCase();

    for (const [key, config] of Object.entries(this.patterns)) {
      for (const pattern of config.patterns) {
        const matches = cleanCommand.match(pattern);
        if (matches) {
          const params = config.extractParams(matches, cleanCommand);
          return {
            intent: config.intent,
            confidence: this.calculateConfidence(matches, cleanCommand),
            params,
            originalCommand: command,
            matchedPattern: key,
          };
        }
      }
    }

    // Fallback to query
    return {
      intent: 'QUERY',
      confidence: 0.5,
      params: { query: command },
      originalCommand: command,
      matchedPattern: 'fallback',
    };
  }

  // Calculate confidence score
  calculateConfidence(matches, command) {
    let confidence = 0.7; // Base confidence

    // Increase confidence for longer matches
    if (matches[1] && matches[1].length > 3) {
      confidence += 0.1;
    }

    // Increase confidence for exact keyword matches
    const keywords = ['vasu', 'please', 'kar', 'karo', 'do'];
    if (keywords.some(k => command.includes(k))) {
      confidence += 0.1;
    }

    // Decrease confidence for very short commands
    if (command.length < 5) {
      confidence -= 0.2;
    }

    return Math.min(confidence, 1.0);
  }

  // Batch parse multiple commands
  parseMultiple(commands) {
    return commands.map(cmd => this.parse(cmd));
  }

  // Get command suggestions based on partial input
  getSuggestions(partialCommand) {
    const suggestions = [];
    const lower = partialCommand.toLowerCase();

    if (lower.includes('open') || lower.includes('khol')) {
      suggestions.push('open youtube', 'open chrome', 'open whatsapp');
    }
    if (lower.includes('call') || lower.includes('phone')) {
      suggestions.push('call papa', 'call mom', 'call boss');
    }
    if (lower.includes('message') || lower.includes('sms')) {
      suggestions.push('send whatsapp to mom: hello', 'sms to 9876543210: hi');
    }
    if (lower.includes('wifi') || lower.includes('bluetooth')) {
      suggestions.push('wifi on', 'bluetooth off', 'hotspot on');
    }
    if (lower.includes('play') || lower.includes('music')) {
      suggestions.push('play arijit singh', 'play hindi songs', 'pause music');
    }

    return suggestions;
  }
}

export default new CommandParser();