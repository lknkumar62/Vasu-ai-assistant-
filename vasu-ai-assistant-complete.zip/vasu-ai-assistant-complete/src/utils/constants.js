// Vasu AI - Constants and Configuration

export const COLORS = {
  // Primary
  primary: '#00ff88',
  primaryDark: '#00cc6a',
  primaryLight: '#00ff8850',

  // Secondary
  secondary: '#00ccff',
  secondaryDark: '#0099cc',
  secondaryLight: '#00ccff50',

  // Accent
  accent: '#ffe66d',
  accentDark: '#ccbb55',

  // Semantic
  success: '#00ff88',
  warning: '#ffe66d',
  error: '#ff6b6b',
  info: '#00ccff',

  // Background
  background: '#0a0a0a',
  surface: '#1a1a1a',
  card: '#222',

  // Text
  textPrimary: '#ffffff',
  textSecondary: '#888',
  textDisabled: '#666',

  // Border
  border: '#333',
  borderLight: '#444',

  // Overlay
  overlay: '#00000080',
};

export const FONTS = {
  regular: 'System',
  medium: 'System',
  bold: 'System',
  mono: 'monospace',
};

export const SIZES = {
  xs: 10,
  sm: 12,
  md: 14,
  lg: 16,
  xl: 18,
  xxl: 20,
  xxxl: 24,
  display: 32,
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const BORDER_RADIUS = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  xxl: 20,
  round: 999,
};

export const SHADOWS = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  lg: {
    shadowColor: '#00ff88',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
};

export const ANIMATION = {
  duration: {
    fast: 150,
    normal: 300,
    slow: 500,
  },
  easing: {
    default: 'ease-in-out',
    bounce: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
  },
};

export const WAKE_WORDS = [
  'vasu',
  'wasu',
  'vassu',
  'boss',
  'assistant',
  'hey vasu',
  'ok vasu',
];

export const SUPPORTED_APPS = {
  youtube: { package: 'com.google.android.youtube', ios: 'youtube://', color: '#ff0000' },
  chrome: { package: 'com.android.chrome', ios: 'googlechrome://', color: '#4285f4' },
  whatsapp: { package: 'com.whatsapp', ios: 'whatsapp://', color: '#25d366' },
  instagram: { package: 'com.instagram.android', ios: 'instagram://', color: '#e4405f' },
  facebook: { package: 'com.facebook.katana', ios: 'fb://', color: '#1877f2' },
  twitter: { package: 'com.twitter.android', ios: 'twitter://', color: '#1da1f2' },
  gmail: { package: 'com.google.android.gm', ios: 'googlegmail://', color: '#ea4335' },
  maps: { package: 'com.google.android.apps.maps', ios: 'comgooglemaps://', color: '#4285f4' },
  spotify: { package: 'com.spotify.music', ios: 'spotify://', color: '#1db954' },
  netflix: { package: 'com.netflix.mediaclient', ios: 'nflx://', color: '#e50914' },
  settings: { package: 'com.android.settings', ios: 'app-settings://', color: '#888' },
  camera: { package: 'com.android.camera', ios: 'camera://', color: '#888' },
  calculator: { package: 'com.android.calculator2', ios: 'calculator://', color: '#888' },
  clock: { package: 'com.android.deskclock', ios: 'clock://', color: '#888' },
  calendar: { package: 'com.android.calendar', ios: 'calshow://', color: '#888' },
  contacts: { package: 'com.android.contacts', ios: 'contacts://', color: '#888' },
  phone: { package: 'com.android.dialer', ios: 'tel://', color: '#888' },
  messages: { package: 'com.android.messaging', ios: 'sms://', color: '#888' },
};

export const DEPLOYMENT_PLATFORMS = [
  { id: 'vercel', name: 'Vercel', color: '#ffffff' },
  { id: 'netlify', name: 'Netlify', color: '#00ad9f' },
  { id: 'github', name: 'GitHub Pages', color: '#f5f5f5' },
  { id: 'firebase', name: 'Firebase', color: '#ffca28' },
  { id: 'heroku', name: 'Heroku', color: '#6762a6' },
  { id: 'aws', name: 'AWS Amplify', color: '#ff9900' },
];

export const CODE_TEMPLATES = [
  { id: 'react', name: 'React', language: 'javascript', icon: 'logo-react' },
  { id: 'node', name: 'Node.js', language: 'javascript', icon: 'server' },
  { id: 'python', name: 'Python', language: 'python', icon: 'logo-python' },
  { id: 'flutter', name: 'Flutter', language: 'dart', icon: 'phone-portrait' },
  { id: 'html', name: 'HTML', language: 'html', icon: 'globe' },
  { id: 'nextjs', name: 'Next.js', language: 'javascript', icon: 'triangle' },
];

export const LEARNING_TOPICS = [
  { id: 'spanish', name: 'Spanish', icon: 'language', color: '#ff6b6b' },
  { id: 'french', name: 'French', icon: 'language', color: '#00ccff' },
  { id: 'german', name: 'German', icon: 'language', color: '#ffe66d' },
  { id: 'japanese', name: 'Japanese', icon: 'language', color: '#ff8b94' },
  { id: 'coding', name: 'Coding', icon: 'code-slash', color: '#00ff88' },
  { id: 'gk', name: 'General Knowledge', icon: 'book', color: '#00ccff' },
  { id: 'math', name: 'Mathematics', icon: 'calculator', color: '#a8e6cf' },
  { id: 'science', name: 'Science', icon: 'flask', color: '#c7ceea' },
];

export const SECURITY_LEVELS = {
  LOW: ['search', 'open', 'play', 'volume', 'brightness'],
  MEDIUM: ['message', 'call', 'wifi', 'bluetooth', 'location'],
  HIGH: ['delete', 'format', 'reset', 'payment', 'transfer'],
  CRITICAL: ['factory_reset', 'wipe_data', 'root_access', 'system_modify'],
};

export const VOICE_SETTINGS = {
  pitch: 1.0,
  rate: 0.9,
  volume: 1.0,
  language: 'hi-IN',
};

export const NOTIFICATION_CHANNELS = {
  general: { id: 'general', name: 'General', importance: 'default' },
  reminders: { id: 'reminders', name: 'Reminders', importance: 'high' },
  learning: { id: 'learning', name: 'Learning', importance: 'default' },
  security: { id: 'security', name: 'Security', importance: 'high' },
};

export const MAX_FAILED_ATTEMPTS = 3;
export const AUTO_LOCK_TIMEOUT = 300000; // 5 minutes
export const WAKE_WORD_SENSITIVITY = 0.7;
export const VOICE_LEVEL_THRESHOLD = 30;
export const SILENCE_TIMEOUT = 3000; // 3 seconds

export default {
  COLORS,
  FONTS,
  SIZES,
  SPACING,
  BORDER_RADIUS,
  SHADOWS,
  ANIMATION,
  WAKE_WORDS,
  SUPPORTED_APPS,
  DEPLOYMENT_PLATFORMS,
  CODE_TEMPLATES,
  LEARNING_TOPICS,
  SECURITY_LEVELS,
  VOICE_SETTINGS,
  NOTIFICATION_CHANNELS,
  MAX_FAILED_ATTEMPTS,
  AUTO_LOCK_TIMEOUT,
  WAKE_WORD_SENSITIVITY,
  VOICE_LEVEL_THRESHOLD,
  SILENCE_TIMEOUT,
};