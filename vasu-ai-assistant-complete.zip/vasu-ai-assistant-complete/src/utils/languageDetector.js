// Language Detection Utility for Vasu AI
// Detects Hindi, English, or Hinglish (mix)

class LanguageDetector {
  constructor() {
    // Hindi character range (Devanagari)
    this.hindiPattern = /[\u0900-\u097F]/;

    // Common Hindi words
    this.hindiWords = [
      'hai', 'hain', 'ho', 'hoga', 'karo', 'karein', 'kiya', 'kar', 'karo',
      'batao', 'bataiye', 'suno', 'suniye', 'dekho', 'dekhiye', 'chalo', 'chaliye',
      'ruko', 'rukije', 'haan', 'nahi', 'haanji', 'namaste', 'dhanyawad', 'shukriya',
      'kya', 'kaun', 'kab', 'kahan', 'kyon', 'kaise', 'kitna', 'kaunsa',
      'mera', 'tera', 'uska', 'hamara', 'tumhara', 'inka', 'unka',
      'mujhe', 'tujhe', 'use', 'hamein', 'tumhein', 'inse', 'unse',
      'mein', 'par', 'se', 'ko', 'ke', 'ki', 'ka', 'ne', 'bhi', 'hi',
      'aur', 'ya', 'lekin', 'magar', 'kyunki', 'agar', 'toh', 'tab',
      'ek', 'do', 'teen', 'char', 'paanch', 'che', 'saat', 'aath', 'nau', 'das',
      'acha', 'bahut', 'zyada', 'kam', 'tez', 'dheere', 'jaldi', 'der',
      'kholo', 'band', 'chalu', 'bujhao', 'on', 'off',
      'bhejo', 'bhejiye', 'likho', 'likhiye', 'padho', 'padhiye',
    ];

    // Common English words (for detection)
    this.englishWords = [
      'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
      'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
      'could', 'should', 'may', 'might', 'must', 'shall', 'can',
      'need', 'dare', 'ought', 'used', 'to', 'of', 'in', 'for',
      'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through',
      'during', 'before', 'after', 'above', 'below', 'between',
      'under', 'again', 'further', 'then', 'once', 'here', 'there',
      'when', 'where', 'why', 'how', 'all', 'each', 'few', 'more',
      'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only',
      'own', 'same', 'so', 'than', 'too', 'very', 'just', 'now',
    ];
  }

  // Detect language of text
  detect(text) {
    if (!text || typeof text !== 'string') {
      return { language: 'unknown', confidence: 0, isMixed: false };
    }

    const cleanText = text.toLowerCase().trim();

    // Check for Hindi characters (Devanagari script)
    const hasHindiChars = this.hindiPattern.test(cleanText);

    // Count Hindi words
    const words = cleanText.split(/\s+/);
    const hindiWordCount = words.filter(w => this.hindiWords.includes(w)).length;
    const englishWordCount = words.filter(w => this.englishWords.includes(w)).length;

    const totalWords = words.length;
    const hindiRatio = hindiWordCount / totalWords;
    const englishRatio = englishWordCount / totalWords;

    // Determine language
    let language, confidence, isMixed;

    if (hasHindiChars) {
      // Pure Hindi (Devanagari script)
      language = 'hi';
      confidence = 0.95;
      isMixed = false;
    } else if (hindiRatio > 0.3 && englishRatio > 0.3) {
      // Hinglish (significant mix)
      language = 'hi-EN';
      confidence = Math.min(hindiRatio + englishRatio, 0.95);
      isMixed = true;
    } else if (hindiRatio > 0.5) {
      // Mostly Hindi words in Roman script
      language = 'hi-EN';
      confidence = hindiRatio;
      isMixed = true;
    } else if (englishRatio > 0.5) {
      // Mostly English
      language = 'en';
      confidence = englishRatio;
      isMixed = false;
    } else {
      // Default to Hinglish for unclear cases
      language = 'hi-EN';
      confidence = 0.5;
      isMixed = true;
    }

    return {
      language,
      confidence: Math.round(confidence * 100),
      isMixed,
      hindiRatio: Math.round(hindiRatio * 100),
      englishRatio: Math.round(englishRatio * 100),
      hasHindiChars,
    };
  }

  // Get language name for display
  getLanguageName(code) {
    const names = {
      'hi': 'Hindi',
      'en': 'English',
      'hi-EN': 'Hinglish (Hindi + English)',
      'unknown': 'Unknown',
    };
    return names[code] || code;
  }

  // Get speech language code
  getSpeechLanguage(code) {
    const speechCodes = {
      'hi': 'hi-IN',
      'en': 'en-US',
      'hi-EN': 'hi-IN', // Default to Hindi for Hinglish
      'unknown': 'en-US',
    };
    return speechCodes[code] || 'en-US';
  }

  // Detect and suggest corrections
  suggestCorrections(text) {
    const detected = this.detect(text);
    const suggestions = [];

    if (detected.language === 'hi-EN') {
      // Common Hinglish corrections
      const corrections = {
        'karo': 'kar',
        'batao': 'bataiye',
        'sun': 'suniye',
        'dekho': 'dekhiye',
        'chalo': 'chaliye',
        'ruko': 'rukije',
      };

      Object.entries(corrections).forEach(([wrong, correct]) => {
        if (text.toLowerCase().includes(wrong)) {
          suggestions.push({
            original: wrong,
            suggestion: correct,
            reason: 'More polite/formal form',
          });
        }
      });
    }

    return {
      detected,
      suggestions,
    };
  }

  // Batch detect
  detectMultiple(texts) {
    return texts.map(text => this.detect(text));
  }
}

export default new LanguageDetector();