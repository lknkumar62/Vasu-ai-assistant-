import React, { createContext, useContext, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const MemoryContext = createContext();

// Spaced Repetition Intervals (in minutes)
const SRS_INTERVALS = [2, 10, 60, 240, 1440, 4320, 10080]; // 2min, 10min, 1hr, 4hr, 1day, 3days, 7days

export function MemoryProvider({ children }) {
  const [memory, setMemory] = useState({});
  const [learningItems, setLearningItems] = useState([]);
  const [userHabits, setUserHabits] = useState({});
  const [commandPatterns, setCommandPatterns] = useState([]);

  // Save data to persistent storage
  const saveToMemory = useCallback(async (key, data) => {
    try {
      const timestamp = Date.now();
      const memoryItem = {
        data,
        timestamp,
        accessCount: 1,
        lastAccessed: timestamp,
      };

      await AsyncStorage.setItem(`vasu_memory_${key}`, JSON.stringify(memoryItem));

      setMemory(prev => ({
        ...prev,
        [key]: memoryItem
      }));

      return true;
    } catch (error) {
      console.error('Save memory error:', error);
      return false;
    }
  }, []);

  // Retrieve data from memory
  const getFromMemory = useCallback(async (key) => {
    try {
      const stored = await AsyncStorage.getItem(`vasu_memory_${key}`);
      if (stored) {
        const item = JSON.parse(stored);
        // Update access stats
        item.accessCount += 1;
        item.lastAccessed = Date.now();
        await AsyncStorage.setItem(`vasu_memory_${key}`, JSON.stringify(item));
        return item.data;
      }
      return null;
    } catch (error) {
      console.error('Get memory error:', error);
      return null;
    }
  }, []);

  // Add learning item with SRS
  const addLearningItem = useCallback(async (item) => {
    try {
      const learningItem = {
        id: Date.now().toString(),
        content: item,
        createdAt: Date.now(),
        stage: 0, // SRS stage
        nextReview: Date.now() + (SRS_INTERVALS[0] * 60 * 1000),
        reviewCount: 0,
        confidence: 0,
        lastReviewed: null,
        isMastered: false,
      };

      const existing = await AsyncStorage.getItem('vasu_learning_items');
      const items = existing ? JSON.parse(existing) : [];
      items.push(learningItem);

      await AsyncStorage.setItem('vasu_learning_items', JSON.stringify(items));
      setLearningItems(items);

      return learningItem.id;
    } catch (error) {
      console.error('Add learning item error:', error);
      return null;
    }
  }, []);

  // Review item and update SRS
  const reviewItem = useCallback(async (itemId, confidence) => {
    try {
      const stored = await AsyncStorage.getItem('vasu_learning_items');
      const items = stored ? JSON.parse(stored) : [];

      const itemIndex = items.findIndex(i => i.id === itemId);
      if (itemIndex === -1) return false;

      const item = items[itemIndex];
      item.lastReviewed = Date.now();
      item.reviewCount += 1;
      item.confidence = confidence;

      // Update stage based on confidence
      if (confidence >= 80) {
        item.stage = Math.min(item.stage + 1, SRS_INTERVALS.length - 1);
      } else if (confidence < 50) {
        item.stage = Math.max(item.stage - 1, 0);
      }

      // Check if mastered
      if (item.stage >= SRS_INTERVALS.length - 1 && confidence >= 90) {
        item.isMastered = true;
      }

      // Set next review
      const intervalMinutes = SRS_INTERVALS[item.stage];
      item.nextReview = Date.now() + (intervalMinutes * 60 * 1000);

      items[itemIndex] = item;
      await AsyncStorage.setItem('vasu_learning_items', JSON.stringify(items));
      setLearningItems(items);

      return true;
    } catch (error) {
      console.error('Review item error:', error);
      return false;
    }
  }, []);

  // Get items due for review
  const getDueItems = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem('vasu_learning_items');
      const items = stored ? JSON.parse(stored) : [];
      const now = Date.now();

      return items.filter(item => item.nextReview <= now && !item.isMastered);
    } catch (error) {
      console.error('Get due items error:', error);
      return [];
    }
  }, []);

  // Track user habits
  const trackHabit = useCallback(async (action, context) => {
    try {
      const habitKey = `habit_${action}`;
      const stored = await AsyncStorage.getItem(habitKey);
      const habit = stored ? JSON.parse(stored) : {
        action,
        count: 0,
        contexts: [],
        timePatterns: [],
        lastUsed: null,
      };

      habit.count += 1;
      habit.contexts.push(context);
      habit.timePatterns.push(new Date().getHours());
      habit.lastUsed = Date.now();

      // Keep only last 50 contexts
      if (habit.contexts.length > 50) {
        habit.contexts = habit.contexts.slice(-50);
        habit.timePatterns = habit.timePatterns.slice(-50);
      }

      await AsyncStorage.setItem(habitKey, JSON.stringify(habit));

      setUserHabits(prev => ({
        ...prev,
        [action]: habit
      }));

      return habit;
    } catch (error) {
      console.error('Track habit error:', error);
      return null;
    }
  }, []);

  // Get suggested actions based on habits
  const getSuggestions = useCallback(async () => {
    try {
      const suggestions = [];
      const currentHour = new Date().getHours();

      for (const [action, habit] of Object.entries(userHabits)) {
        // Check if this action is typically done at this time
        const hourMatches = habit.timePatterns.filter(h => 
          Math.abs(h - currentHour) <= 1
        ).length;

        if (hourMatches > 3) {
          suggestions.push({
            action,
            confidence: (hourMatches / habit.timePatterns.length) * 100,
            context: habit.contexts[habit.contexts.length - 1],
          });
        }
      }

      return suggestions.sort((a, b) => b.confidence - a.confidence).slice(0, 5);
    } catch (error) {
      console.error('Get suggestions error:', error);
      return [];
    }
  }, [userHabits]);

  // Save command pattern for learning
  const saveCommandPattern = useCallback(async (command, intent, success) => {
    try {
      const pattern = {
        command,
        intent,
        success,
        timestamp: Date.now(),
        frequency: 1,
      };

      const stored = await AsyncStorage.getItem('vasu_command_patterns');
      const patterns = stored ? JSON.parse(stored) : [];

      // Update frequency if pattern exists
      const existingIndex = patterns.findIndex(p => 
        p.command.toLowerCase() === command.toLowerCase()
      );

      if (existingIndex !== -1) {
        patterns[existingIndex].frequency += 1;
        patterns[existingIndex].lastUsed = Date.now();
      } else {
        patterns.push(pattern);
      }

      await AsyncStorage.setItem('vasu_command_patterns', JSON.stringify(patterns));
      setCommandPatterns(patterns);

      return true;
    } catch (error) {
      console.error('Save command pattern error:', error);
      return false;
    }
  }, []);

  // Get all memory stats
  const getMemoryStats = useCallback(async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const memoryKeys = keys.filter(k => k.startsWith('vasu_memory_'));
      const learningKeys = keys.filter(k => k.startsWith('vasu_learning_'));

      return {
        totalMemoryItems: memoryKeys.length,
        totalLearningItems: learningKeys.length,
        masteredItems: learningItems.filter(i => i.isMastered).length,
        dueItems: (await getDueItems()).length,
        habitsTracked: Object.keys(userHabits).length,
        commandPatterns: commandPatterns.length,
      };
    } catch (error) {
      console.error('Get memory stats error:', error);
      return {};
    }
  }, [learningItems, userHabits, commandPatterns, getDueItems]);

  // Clear all memory
  const clearAllMemory = useCallback(async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const vasuKeys = keys.filter(k => k.startsWith('vasu_'));
      await AsyncStorage.multiRemove(vasuKeys);

      setMemory({});
      setLearningItems([]);
      setUserHabits({});
      setCommandPatterns([]);

      return true;
    } catch (error) {
      console.error('Clear memory error:', error);
      return false;
    }
  }, []);

  return (
    <MemoryContext.Provider value={{
      memory,
      learningItems,
      userHabits,
      commandPatterns,
      saveToMemory,
      getFromMemory,
      addLearningItem,
      reviewItem,
      getDueItems,
      trackHabit,
      getSuggestions,
      saveCommandPattern,
      getMemoryStats,
      clearAllMemory,
    }}>
      {children}
    </MemoryContext.Provider>
  );
}

export const useMemory = () => {
  const context = useContext(MemoryContext);
  if (!context) throw new Error('useMemory must be used within MemoryProvider');
  return context;
};