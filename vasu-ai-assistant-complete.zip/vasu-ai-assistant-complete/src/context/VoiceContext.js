import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { Platform } from 'react-native';
import * as Speech from 'expo-speech';
import { Audio } from 'expo-av';
import { useVasu } from './VasuContext';
import { useMemory } from './MemoryContext';
import { useSecurity } from './SecurityContext';

const VoiceContext = createContext();

// Wake word detection using simple keyword matching (can be replaced with Porcupine)
const WAKE_WORD = 'vasu';
const WAKE_WORD_ALIASES = ['vasu', 'wasu', 'vassu', 'boss', 'assistant'];

export function VoiceProvider({ children }) {
  const { state, startListening, stopListening, setProcessing, setReady, setCommand, setResponse, addNotification } = useVasu();
  const { saveToMemory, getFromMemory } = useMemory();
  const { verifyVoice, isAuthenticated } = useSecurity();

  const [recording, setRecording] = useState(null);
  const [transcript, setTranscript] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceLevel, setVoiceLevel] = useState(0);
  const [language, setLanguage] = useState('hi-EN');

  const recognitionRef = useRef(null);
  const silenceTimerRef = useRef(null);
  const isListeningRef = useRef(false);

  // Initialize voice recognition
  useEffect(() => {
    initializeVoice();
    return () => {
      if (recording) {
        recording.stopAndUnloadAsync();
      }
      if (silenceTimerRef.current) {
        clearTimeout(silenceTimerRef.current);
      }
    };
  }, []);

  const initializeVoice = async () => {
    try {
      await Audio.requestPermissionsAsync();
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        playThroughEarpieceAndroid: false,
      });
    } catch (error) {
      console.error('Voice initialization error:', error);
    }
  };

  // Start wake word detection (always listening)
  const startWakeWordDetection = useCallback(async () => {
    try {
      const { recording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );
      setRecording(recording);

      // Simulate wake word detection (in production, use Porcupine or similar)
      // This is a simplified version
      const checkWakeWord = setInterval(async () => {
        const status = await recording.getStatusAsync();
        if (status.isRecording) {
          // In real implementation, analyze audio buffer for wake word
          // For now, we'll use a mock detection
        }
      }, 100);

      return () => clearInterval(checkWakeWord);
    } catch (error) {
      console.error('Wake word detection error:', error);
    }
  }, []);

  // Start listening for commands
  const startVoiceRecognition = useCallback(async () => {
    try {
      startListening();
      isListeningRef.current = true;

      // Use native speech recognition
      if (Platform.OS === 'android') {
        // Android: Use native SpeechRecognizer
        await startAndroidRecognition();
      } else {
        // iOS: Use native SFSpeechRecognizer
        await startIOSRecognition();
      }

      // Start voice level monitoring
      monitorVoiceLevel();

    } catch (error) {
      console.error('Voice recognition error:', error);
      stopListening();
      isListeningRef.current = false;
    }
  }, [startListening]);

  const startAndroidRecognition = async () => {
    // Implementation for Android speech recognition
    // This would use @react-native-voice/voice or similar
    console.log('Starting Android voice recognition...');
  };

  const startIOSRecognition = async () => {
    // Implementation for iOS speech recognition
    console.log('Starting iOS voice recognition...');
  };

  // Monitor voice input levels for visual feedback
  const monitorVoiceLevel = useCallback(() => {
    const interval = setInterval(() => {
      if (isListeningRef.current) {
        // Simulate voice levels (0-100)
        const level = Math.floor(Math.random() * 80) + 20;
        setVoiceLevel(level);
      } else {
        setVoiceLevel(0);
        clearInterval(interval);
      }
    }, 100);
  }, []);

  // Stop listening
  const stopVoiceRecognition = useCallback(async () => {
    try {
      isListeningRef.current = false;

      if (recording) {
        await recording.stopAndUnloadAsync();
        setRecording(null);
      }

      if (silenceTimerRef.current) {
        clearTimeout(silenceTimerRef.current);
      }

      stopListening();
      setVoiceLevel(0);

    } catch (error) {
      console.error('Stop recognition error:', error);
    }
  }, [recording, stopListening]);

  // Process voice command
  const processCommand = useCallback(async (commandText) => {
    try {
      setProcessing();
      setCommand(commandText);

      // Check if it's a wake word
      const lowerCommand = commandText.toLowerCase().trim();

      if (WAKE_WORD_ALIASES.some(alias => lowerCommand.includes(alias))) {
        // Extract actual command after wake word
        const wakeIndex = WAKE_WORD_ALIASES.findIndex(alias => lowerCommand.includes(alias));
        const actualCommand = lowerCommand.split(WAKE_WORD_ALIASES[wakeIndex])[1]?.trim() || '';

        if (actualCommand) {
          await executeCommand(actualCommand);
        } else {
          speak('Haan ji, main sun raha hoon. Kya kehna chahte hain?');
        }
      } else {
        // Direct command without wake word (if already active)
        await executeCommand(lowerCommand);
      }

    } catch (error) {
      console.error('Command processing error:', error);
      speak('Maaf kijiye, command samajh nahi aayi. Phir se koshish karein.');
    } finally {
      setReady();
    }
  }, [setProcessing, setCommand, setReady]);

  // Execute command based on intent
  const executeCommand = useCallback(async (command) => {
    try {
      // Save to memory for learning
      await saveToMemory('last_command', { text: command, timestamp: Date.now() });

      // Parse intent
      const intent = parseIntent(command);

      switch (intent.type) {
        case 'OPEN_APP':
          await handleOpenApp(intent.data);
          break;
        case 'CALL':
          await handleCall(intent.data);
          break;
        case 'MESSAGE':
          await handleMessage(intent.data);
          break;
        case 'SETTINGS':
          await handleSettings(intent.data);
          break;
        case 'SEARCH':
          await handleSearch(intent.data);
          break;
        case 'MEDIA':
          await handleMedia(intent.data);
          break;
        case 'CODE':
          await handleCoding(intent.data);
          break;
        case 'DEPLOY':
          await handleDeployment(intent.data);
          break;
        case 'AUTOMATION':
          await handleAutomation(intent.data);
          break;
        case 'LEARN':
          await handleLearning(intent.data);
          break;
        case 'QUERY':
          await handleQuery(intent.data);
          break;
        default:
          speak('Yeh command abhi support nahi hai. Kuch aur try karein.');
      }

    } catch (error) {
      console.error('Execute command error:', error);
      speak('Command execute karne mein error aaya.');
    }
  }, [saveToMemory]);

  // Parse intent from natural language
  const parseIntent = (command) => {
    const lower = command.toLowerCase();

    // App control
    if (lower.match(/(open|launch|start|khol|chalu)\s+(.+)/)) {
      const app = lower.match(/(open|launch|start|khol|chalu)\s+(.+)/)[2];
      return { type: 'OPEN_APP', data: app };
    }

    // Calls
    if (lower.match(/(call|phone|dial|call karo)\s+(.+)/)) {
      const contact = lower.match(/(call|phone|dial|call karo)\s+(.+)/)[2];
      return { type: 'CALL', data: contact };
    }

    // Messages
    if (lower.match(/(send|message|text|whatsapp|sms)\s+(.+)/)) {
      return { type: 'MESSAGE', data: command };
    }

    // Settings
    if (lower.match(/(turn on|turn off|enable|disable|wifi|bluetooth|flashlight|volume|brightness)/)) {
      return { type: 'SETTINGS', data: command };
    }

    // Search
    if (lower.match(/(search|google|youtube|find|dhundo|dikhao)\s+(.+)/)) {
      const query = lower.match(/(search|google|youtube|find|dhundo|dikhao)\s+(.+)/)[2];
      return { type: 'SEARCH', data: query };
    }

    // Media
    if (lower.match(/(play|music|song|video|movie|gaana|gana)/)) {
      return { type: 'MEDIA', data: command };
    }

    // Coding
    if (lower.match(/(code|program|build|create app|website|script|coding)/)) {
      return { type: 'CODE', data: command };
    }

    // Deployment
    if (lower.match(/(deploy|host|publish|live|server|vercel|netlify)/)) {
      return { type: 'DEPLOY', data: command };
    }

    // Automation
    if (lower.match(/(routine|shortcut|automation|schedule|task|workflow)/)) {
      return { type: 'AUTOMATION', data: command };
    }

    // Learning
    if (lower.match(/(sikhao|teach|learn|study|yaad|memory|revision)/)) {
      return { type: 'LEARN', data: command };
    }

    // General query
    return { type: 'QUERY', data: command };
  };

  // Command handlers
  const handleOpenApp = async (appName) => {
    const apps = {
      'youtube': 'com.google.android.youtube',
      'chrome': 'com.android.chrome',
      'whatsapp': 'com.whatsapp',
      'instagram': 'com.instagram.android',
      'facebook': 'com.facebook.katana',
      'twitter': 'com.twitter.android',
      'gmail': 'com.google.android.gm',
      'maps': 'com.google.android.apps.maps',
      'spotify': 'com.spotify.music',
      'netflix': 'com.netflix.mediaclient',
      'settings': 'com.android.settings',
      'camera': 'com.android.camera',
      'gallery': 'com.android.gallery3d',
      'calculator': 'com.android.calculator2',
      'clock': 'com.android.deskclock',
      'calendar': 'com.android.calendar',
      'contacts': 'com.android.contacts',
      'phone': 'com.android.dialer',
      'messages': 'com.android.messaging',
      'files': 'com.android.documentsui',
      'play store': 'com.android.vending',
      'vscode': 'com.microsoft.vscode',
      'terminal': 'com.termux',
      'github': 'com.github.android',
    };

    const packageName = apps[appName.toLowerCase()];
    if (packageName) {
      speak(`${appName} open kar raha hoon.`);
      // Launch app using native module
      // In production: use react-native-app-launcher or similar
      addNotification({ type: 'app', message: `Opened ${appName}`, timestamp: Date.now() });
    } else {
      speak(`Sorry, ${appName} app nahi mila. Kuch aur try karein.`);
    }
  };

  const handleCall = async (contact) => {
    speak(`${contact} ko call kar raha hoon.`);
    // Use react-native-phone-call or native module
    addNotification({ type: 'call', message: `Calling ${contact}`, timestamp: Date.now() });
  };

  const handleMessage = async (data) => {
    // Parse: "Send WhatsApp to Mom: I'm coming"
    const match = data.match(/(?:send|message|text|whatsapp)\s+(?:to\s+)?(.+?):\s*(.+)/i);
    if (match) {
      const [_, contact, message] = match;
      speak(`${contact} ko message bhej raha hoon: ${message}`);
      addNotification({ type: 'message', message: `Sent to ${contact}`, timestamp: Date.now() });
    } else {
      speak('Message format samajh nahi aaya. "Send WhatsApp to [Name]: [Message]" try karein.');
    }
  };

  const handleSettings = async (command) => {
    const lower = command.toLowerCase();

    if (lower.includes('wifi')) {
      const turnOn = lower.includes('on') || lower.includes('chalu') || lower.includes('enable');
      speak(`WiFi ${turnOn ? 'on' : 'off'} kar raha hoon.`);
      // Use native module to toggle WiFi
    }
    else if (lower.includes('bluetooth')) {
      const turnOn = lower.includes('on') || lower.includes('chalu') || lower.includes('enable');
      speak(`Bluetooth ${turnOn ? 'on' : 'off'} kar raha hoon.`);
    }
    else if (lower.includes('flashlight') || lower.includes('torch')) {
      const turnOn = lower.includes('on') || lower.includes('chalu') || lower.includes('enable');
      speak(`Flashlight ${turnOn ? 'on' : 'off'} kar raha hoon.`);
    }
    else if (lower.includes('volume')) {
      const level = lower.match(/\d+/)?.[0] || '50';
      speak(`Volume ${level}% par set kar raha hoon.`);
    }
    else if (lower.includes('brightness')) {
      const level = lower.match(/\d+/)?.[0] || '70';
      speak(`Brightness ${level}% par set kar raha hoon.`);
    }
    else if (lower.includes('do not disturb') || lower.includes('silent')) {
      speak('Do Not Disturb mode toggle kar raha hoon.');
    }
    else {
      speak('Setting samajh nahi aayi. Kuch aur try karein.');
    }
  };

  const handleSearch = async (query) => {
    speak(`${query} search kar raha hoon.`);
    // Open browser with search query
    // Use react-native-inappbrowser-reborn
    addNotification({ type: 'search', message: `Searched: ${query}`, timestamp: Date.now() });
  };

  const handleMedia = async (command) => {
    const lower = command.toLowerCase();

    if (lower.includes('play')) {
      const song = lower.replace(/play\s+/, '');
      speak(`${song} play kar raha hoon.`);
      // Use react-native-track-player or native music app
    }
    else if (lower.includes('pause') || lower.includes('stop')) {
      speak('Music pause kar raha hoon.');
    }
    else if (lower.includes('next')) {
      speak('Next song play kar raha hoon.');
    }
    else if (lower.includes('previous') || lower.includes('back')) {
      speak('Previous song play kar raha hoon.');
    }
  };

  const handleCoding = async (command) => {
    speak('Coding mode activate kar raha hoon. Aap bataiye kya banana hai.');
    // Switch to coding screen
    // Use AI to generate code based on voice description
  };

  const handleDeployment = async (command) => {
    speak('Deployment process shuru kar raha hoon.');
    // Handle deployment to Vercel, Netlify, etc.
  };

  const handleAutomation = async (command) => {
    speak('Automation setup kar raha hoon.');
    // Create custom shortcuts and routines
  };

  const handleLearning = async (command) => {
    speak('Learning mode on. Kya sikhna chahte hain?');
    // Activate spaced repetition and memory system
  };

  const handleQuery = async (query) => {
    // Use AI to answer general queries
    speak('Main soch raha hoon...');
    // Call OpenAI API or similar
    setTimeout(() => {
      speak('Yeh raha aapka jawab: ' + query);
    }, 1500);
  };

  // Text-to-Speech
  const speak = useCallback(async (text, options = {}) => {
    try {
      setIsSpeaking(true);

      const speechOptions = {
        language: language === 'hi-EN' ? 'hi-IN' : 'en-US',
        pitch: 1.0,
        rate: 0.9,
        ...options
      };

      await Speech.speak(text, {
        ...speechOptions,
        onDone: () => setIsSpeaking(false),
        onError: () => setIsSpeaking(false),
      });

    } catch (error) {
      console.error('Speech error:', error);
      setIsSpeaking(false);
    }
  }, [language]);

  // Stop speaking
  const stopSpeaking = useCallback(async () => {
    try {
      await Speech.stop();
      setIsSpeaking(false);
    } catch (error) {
      console.error('Stop speech error:', error);
    }
  }, []);

  return (
    <VoiceContext.Provider value={{
      transcript,
      isSpeaking,
      voiceLevel,
      language,
      setLanguage,
      startVoiceRecognition,
      stopVoiceRecognition,
      processCommand,
      speak,
      stopSpeaking,
      startWakeWordDetection,
    }}>
      {children}
    </VoiceContext.Provider>
  );
}

export const useVoice = () => {
  const context = useContext(VoiceContext);
  if (!context) throw new Error('useVoice must be used within VoiceProvider');
  return context;
};