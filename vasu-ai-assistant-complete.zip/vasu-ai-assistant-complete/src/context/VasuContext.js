import React, { createContext, useContext, useReducer, useCallback } from 'react';

const VasuContext = createContext();

const initialState = {
  isListening: false,
  isProcessing: false,
  currentCommand: null,
  lastResponse: null,
  commandHistory: [],
  activeMode: 'normal', // normal, accessibility, coding, automation
  language: 'hi-EN', // Hindi + English mix
  wakeWord: 'Vasu',
  isOnline: true,
  systemStatus: 'ready',
  errors: [],
  notifications: [],
  activeApps: [],
  deviceStatus: {
    wifi: false,
    bluetooth: false,
    flashlight: false,
    volume: 50,
    brightness: 70,
    battery: 100,
    doNotDisturb: false,
    airplaneMode: false,
    location: false,
    hotspot: false
  }
};

function vasuReducer(state, action) {
  switch (action.type) {
    case 'START_LISTENING':
      return { ...state, isListening: true, systemStatus: 'listening' };
    case 'STOP_LISTENING':
      return { ...state, isListening: false, systemStatus: 'ready' };
    case 'SET_PROCESSING':
      return { ...state, isProcessing: true, systemStatus: 'processing' };
    case 'SET_READY':
      return { ...state, isProcessing: false, systemStatus: 'ready' };
    case 'SET_COMMAND':
      return { ...state, currentCommand: action.payload };
    case 'SET_RESPONSE':
      return { 
        ...state, 
        lastResponse: action.payload,
        commandHistory: [...state.commandHistory, { 
          command: state.currentCommand, 
          response: action.payload,
          timestamp: new Date().toISOString()
        }]
      };
    case 'SET_MODE':
      return { ...state, activeMode: action.payload };
    case 'SET_LANGUAGE':
      return { ...state, language: action.payload };
    case 'SET_WAKE_WORD':
      return { ...state, wakeWord: action.payload };
    case 'SET_ONLINE':
      return { ...state, isOnline: action.payload };
    case 'UPDATE_DEVICE_STATUS':
      return { ...state, deviceStatus: { ...state.deviceStatus, ...action.payload } };
    case 'ADD_NOTIFICATION':
      return { ...state, notifications: [action.payload, ...state.notifications] };
    case 'CLEAR_NOTIFICATIONS':
      return { ...state, notifications: [] };
    case 'ADD_ERROR':
      return { ...state, errors: [action.payload, ...state.errors] };
    case 'CLEAR_ERRORS':
      return { ...state, errors: [] };
    case 'ADD_ACTIVE_APP':
      return { ...state, activeApps: [...state.activeApps, action.payload] };
    case 'REMOVE_ACTIVE_APP':
      return { ...state, activeApps: state.activeApps.filter(app => app !== action.payload) };
    default:
      return state;
  }
}

export function VasuProvider({ children }) {
  const [state, dispatch] = useReducer(vasuReducer, initialState);

  const startListening = useCallback(() => dispatch({ type: 'START_LISTENING' }), []);
  const stopListening = useCallback(() => dispatch({ type: 'STOP_LISTENING' }), []);
  const setProcessing = useCallback(() => dispatch({ type: 'SET_PROCESSING' }), []);
  const setReady = useCallback(() => dispatch({ type: 'SET_READY' }), []);
  const setCommand = useCallback((cmd) => dispatch({ type: 'SET_COMMAND', payload: cmd }), []);
  const setResponse = useCallback((resp) => dispatch({ type: 'SET_RESPONSE', payload: resp }), []);
  const setMode = useCallback((mode) => dispatch({ type: 'SET_MODE', payload: mode }), []);
  const setLanguage = useCallback((lang) => dispatch({ type: 'SET_LANGUAGE', payload: lang }), []);
  const setWakeWord = useCallback((word) => dispatch({ type: 'SET_WAKE_WORD', payload: word }), []);
  const setOnline = useCallback((status) => dispatch({ type: 'SET_ONLINE', payload: status }), []);
  const updateDeviceStatus = useCallback((status) => dispatch({ type: 'UPDATE_DEVICE_STATUS', payload: status }), []);
  const addNotification = useCallback((notif) => dispatch({ type: 'ADD_NOTIFICATION', payload: notif }), []);
  const clearNotifications = useCallback(() => dispatch({ type: 'CLEAR_NOTIFICATIONS' }), []);
  const addError = useCallback((err) => dispatch({ type: 'ADD_ERROR', payload: err }), []);
  const clearErrors = useCallback(() => dispatch({ type: 'CLEAR_ERRORS' }), []);

  return (
    <VasuContext.Provider value={{
      state,
      startListening,
      stopListening,
      setProcessing,
      setReady,
      setCommand,
      setResponse,
      setMode,
      setLanguage,
      setWakeWord,
      setOnline,
      updateDeviceStatus,
      addNotification,
      clearNotifications,
      addError,
      clearErrors
    }}>
      {children}
    </VasuContext.Provider>
  );
}

export const useVasu = () => {
  const context = useContext(VasuContext);
  if (!context) throw new Error('useVasu must be used within VasuProvider');
  return context;
};