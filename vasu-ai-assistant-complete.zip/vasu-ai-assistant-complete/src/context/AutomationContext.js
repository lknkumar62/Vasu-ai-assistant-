import React, { createContext, useContext, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';

const AutomationContext = createContext();

export function AutomationProvider({ children }) {
  const [routines, setRoutines] = useState([]);
  const [scheduledTasks, setScheduledTasks] = useState([]);
  const [activeWorkflows, setActiveWorkflows] = useState([]);

  // Create a new routine/shortcut
  const createRoutine = useCallback(async (name, trigger, actions) => {
    try {
      const routine = {
        id: Date.now().toString(),
        name,
        trigger, // voice command or time/event
        actions, // array of actions to execute
        createdAt: Date.now(),
        isActive: true,
        executionCount: 0,
        lastExecuted: null,
      };

      const stored = await AsyncStorage.getItem('vasu_routines');
      const existing = stored ? JSON.parse(stored) : [];
      existing.push(routine);

      await AsyncStorage.setItem('vasu_routines', JSON.stringify(existing));
      setRoutines(existing);

      return routine.id;
    } catch (error) {
      console.error('Create routine error:', error);
      return null;
    }
  }, []);

  // Execute a routine
  const executeRoutine = useCallback(async (routineId) => {
    try {
      const stored = await AsyncStorage.getItem('vasu_routines');
      const routines = stored ? JSON.parse(stored) : [];
      const routine = routines.find(r => r.id === routineId);

      if (!routine || !routine.isActive) {
        return false;
      }

      // Execute each action in sequence
      for (const action of routine.actions) {
        await executeAction(action);
      }

      // Update stats
      routine.executionCount += 1;
      routine.lastExecuted = Date.now();

      await AsyncStorage.setItem('vasu_routines', JSON.stringify(routines));
      setRoutines(routines);

      return true;
    } catch (error) {
      console.error('Execute routine error:', error);
      return false;
    }
  }, []);

  // Execute single action
  const executeAction = async (action) => {
    switch (action.type) {
      case 'OPEN_APP':
        // Open app
        console.log(`Opening app: ${action.data}`);
        break;
      case 'SET_SETTING':
        // Toggle setting
        console.log(`Setting: ${action.data}`);
        break;
      case 'SEND_MESSAGE':
        // Send message
        console.log(`Sending message to ${action.data.contact}: ${action.data.message}`);
        break;
      case 'PLAY_MEDIA':
        // Play media
        console.log(`Playing: ${action.data}`);
        break;
      case 'NOTIFICATION':
        // Show notification
        await Notifications.scheduleNotificationAsync({
          content: {
            title: action.data.title,
            body: action.data.body,
          },
          trigger: null,
        });
        break;
      case 'DELAY':
        // Wait
        await new Promise(resolve => setTimeout(resolve, action.data * 1000));
        break;
      case 'WEB_SEARCH':
        // Search web
        console.log(`Searching: ${action.data}`);
        break;
      case 'CODE_EXECUTE':
        // Execute code
        console.log(`Executing code: ${action.data}`);
        break;
      default:
        console.log(`Unknown action type: ${action.type}`);
    }
  };

  // Schedule a task
  const scheduleTask = useCallback(async (task) => {
    try {
      const scheduledTask = {
        id: Date.now().toString(),
        ...task,
        status: 'pending',
        createdAt: Date.now(),
      };

      const stored = await AsyncStorage.getItem('vasu_scheduled_tasks');
      const tasks = stored ? JSON.parse(stored) : [];
      tasks.push(scheduledTask);

      await AsyncStorage.setItem('vasu_scheduled_tasks', JSON.stringify(tasks));
      setScheduledTasks(tasks);

      // Schedule notification
      if (task.time) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: 'Vasu Task',
            body: task.name,
          },
          trigger: { date: new Date(task.time) },
        });
      }

      return scheduledTask.id;
    } catch (error) {
      console.error('Schedule task error:', error);
      return null;
    }
  }, []);

  // Cancel scheduled task
  const cancelTask = useCallback(async (taskId) => {
    try {
      const stored = await AsyncStorage.getItem('vasu_scheduled_tasks');
      const tasks = stored ? JSON.parse(stored) : [];
      const updated = tasks.filter(t => t.id !== taskId);

      await AsyncStorage.setItem('vasu_scheduled_tasks', JSON.stringify(updated));
      setScheduledTasks(updated);

      return true;
    } catch (error) {
      console.error('Cancel task error:', error);
      return false;
    }
  }, []);

  // Get all routines
  const getRoutines = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem('vasu_routines');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Get routines error:', error);
      return [];
    }
  }, []);

  // Get all scheduled tasks
  const getScheduledTasks = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem('vasu_scheduled_tasks');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Get scheduled tasks error:', error);
      return [];
    }
  }, []);

  // Delete routine
  const deleteRoutine = useCallback(async (routineId) => {
    try {
      const stored = await AsyncStorage.getItem('vasu_routines');
      const routines = stored ? JSON.parse(stored) : [];
      const updated = routines.filter(r => r.id !== routineId);

      await AsyncStorage.setItem('vasu_routines', JSON.stringify(updated));
      setRoutines(updated);

      return true;
    } catch (error) {
      console.error('Delete routine error:', error);
      return false;
    }
  }, []);

  // Toggle routine active status
  const toggleRoutine = useCallback(async (routineId) => {
    try {
      const stored = await AsyncStorage.getItem('vasu_routines');
      const routines = stored ? JSON.parse(stored) : [];
      const routine = routines.find(r => r.id === routineId);

      if (routine) {
        routine.isActive = !routine.isActive;
        await AsyncStorage.setItem('vasu_routines', JSON.stringify(routines));
        setRoutines(routines);
      }

      return true;
    } catch (error) {
      console.error('Toggle routine error:', error);
      return false;
    }
  }, []);

  return (
    <AutomationContext.Provider value={{
      routines,
      scheduledTasks,
      activeWorkflows,
      createRoutine,
      executeRoutine,
      scheduleTask,
      cancelTask,
      getRoutines,
      getScheduledTasks,
      deleteRoutine,
      toggleRoutine,
    }}>
      {children}
    </AutomationContext.Provider>
  );
}

export const useAutomation = () => {
  const context = useContext(AutomationContext);
  if (!context) throw new Error('useAutomation must be used within AutomationProvider');
  return context;
};