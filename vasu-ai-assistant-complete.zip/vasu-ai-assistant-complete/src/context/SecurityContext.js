import React, { createContext, useContext, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SecurityContext = createContext();

// Risk levels for commands
const RISK_LEVELS = {
  LOW: ['search', 'open', 'play', 'volume', 'brightness'],
  MEDIUM: ['message', 'call', 'wifi', 'bluetooth'],
  HIGH: ['delete', 'format', 'reset', 'payment', 'transfer', 'password'],
  CRITICAL: ['factory_reset', 'wipe_data', 'root_access', 'system_modify']
};

export function SecurityProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [voiceProfile, setVoiceProfile] = useState(null);
  const [securitySettings, setSecuritySettings] = useState({
    voiceAuthEnabled: true,
    pinFallback: true,
    biometricFallback: true,
    confirmationForRisky: true,
    autoLockTimeout: 300000, // 5 minutes
    maxFailedAttempts: 3,
  });
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);

  // Enroll voice profile
  const enrollVoice = useCallback(async (voiceSamples) => {
    try {
      // In production, use voice biometric SDK
      // For now, store sample characteristics
      const profile = {
        samples: voiceSamples,
        createdAt: Date.now(),
        sampleCount: voiceSamples.length,
      };

      await AsyncStorage.setItem('vasu_voice_profile', JSON.stringify(profile));
      setVoiceProfile(profile);

      return true;
    } catch (error) {
      console.error('Voice enrollment error:', error);
      return false;
    }
  }, []);

  // Verify voice against stored profile
  const verifyVoice = useCallback(async (voiceSample) => {
    try {
      if (!securitySettings.voiceAuthEnabled) {
        return true;
      }

      if (!voiceProfile) {
        const stored = await AsyncStorage.getItem('vasu_voice_profile');
        if (stored) {
          setVoiceProfile(JSON.parse(stored));
        } else {
          // No voice profile, allow access
          return true;
        }
      }

      // In production: Use voice biometric comparison
      // For demo: Simple mock verification
      const isMatch = await mockVoiceComparison(voiceSample, voiceProfile);

      if (isMatch) {
        setIsAuthenticated(true);
        setFailedAttempts(0);
        return true;
      } else {
        const newFailed = failedAttempts + 1;
        setFailedAttempts(newFailed);

        if (newFailed >= securitySettings.maxFailedAttempts) {
          setIsLocked(true);
          // Lock for 15 minutes
          setTimeout(() => {
            setIsLocked(false);
            setFailedAttempts(0);
          }, 900000);
        }

        return false;
      }
    } catch (error) {
      console.error('Voice verification error:', error);
      return false;
    }
  }, [voiceProfile, securitySettings, failedAttempts]);

  // Mock voice comparison (replace with real biometric SDK)
  const mockVoiceComparison = async (sample, profile) => {
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 500));
    // Return true for demo (in production, use actual comparison)
    return true;
  };

  // Authenticate with PIN
  const authenticateWithPIN = useCallback(async (pin) => {
    try {
      const storedPIN = await AsyncStorage.getItem('vasu_security_pin');
      if (storedPIN && storedPIN === pin) {
        setIsAuthenticated(true);
        setFailedAttempts(0);
        return true;
      }
      return false;
    } catch (error) {
      console.error('PIN auth error:', error);
      return false;
    }
  }, []);

  // Set security PIN
  const setPIN = useCallback(async (pin) => {
    try {
      await AsyncStorage.setItem('vasu_security_pin', pin);
      return true;
    } catch (error) {
      console.error('Set PIN error:', error);
      return false;
    }
  }, []);

  // Check if action requires confirmation
  const requiresConfirmation = useCallback((command) => {
    if (!securitySettings.confirmationForRisky) return false;

    const lower = command.toLowerCase();

    for (const [level, keywords] of Object.entries(RISK_LEVELS)) {
      if (level === 'LOW') continue;
      if (keywords.some(kw => lower.includes(kw))) {
        return level;
      }
    }

    return false;
  }, [securitySettings]);

  // Log security event
  const logSecurityEvent = useCallback(async (event) => {
    try {
      const stored = await AsyncStorage.getItem('vasu_security_log');
      const logs = stored ? JSON.parse(stored) : [];

      logs.push({
        ...event,
        timestamp: Date.now(),
      });

      // Keep only last 100 logs
      if (logs.length > 100) {
        logs.shift();
      }

      await AsyncStorage.setItem('vasu_security_log', JSON.stringify(logs));
      return true;
    } catch (error) {
      console.error('Log security event error:', error);
      return false;
    }
  }, []);

  // Get security logs
  const getSecurityLogs = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem('vasu_security_log');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Get security logs error:', error);
      return [];
    }
  }, []);

  // Update security settings
  const updateSecuritySettings = useCallback(async (settings) => {
    try {
      const updated = { ...securitySettings, ...settings };
      await AsyncStorage.setItem('vasu_security_settings', JSON.stringify(updated));
      setSecuritySettings(updated);
      return true;
    } catch (error) {
      console.error('Update security settings error:', error);
      return false;
    }
  }, [securitySettings]);

  // Logout / lock
  const lock = useCallback(() => {
    setIsAuthenticated(false);
  }, []);

  // Auto-lock timer
  const startAutoLockTimer = useCallback(() => {
    if (securitySettings.autoLockTimeout > 0) {
      setTimeout(() => {
        lock();
      }, securitySettings.autoLockTimeout);
    }
  }, [securitySettings.autoLockTimeout, lock]);

  return (
    <SecurityContext.Provider value={{
      isAuthenticated,
      isLocked,
      voiceProfile,
      securitySettings,
      failedAttempts,
      enrollVoice,
      verifyVoice,
      authenticateWithPIN,
      setPIN,
      requiresConfirmation,
      logSecurityEvent,
      getSecurityLogs,
      updateSecuritySettings,
      lock,
      startAutoLockTimer,
    }}>
      {children}
    </SecurityContext.Provider>
  );
}

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (!context) throw new Error('useSecurity must be used within SecurityProvider');
  return context;
};