import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, Dimensions } from 'react-native';

const { width } = Dimensions.get('window');
const BAR_COUNT = 40;

export default function VoiceWaveform({ level = 0, isListening = false }) {
  const bars = useRef(Array(BAR_COUNT).fill(0).map(() => new Animated.Value(5))).current;

  useEffect(() => {
    if (isListening) {
      const animations = bars.map((bar, index) => {
        return Animated.loop(
          Animated.sequence([
            Animated.timing(bar, {
              toValue: Math.random() * 60 + 10,
              duration: 200 + Math.random() * 300,
              useNativeDriver: true,
            }),
            Animated.timing(bar, {
              toValue: 5,
              duration: 200 + Math.random() * 300,
              useNativeDriver: true,
            }),
          ])
        );
      });

      animations.forEach(anim => anim.start());

      return () => {
        animations.forEach(anim => anim.stop());
      };
    } else {
      // Reset bars when not listening
      bars.forEach(bar => {
        Animated.timing(bar, {
          toValue: 5,
          duration: 300,
          useNativeDriver: true,
        }).start();
      });
    }
  }, [isListening]);

  // Adjust animation based on voice level
  useEffect(() => {
    if (isListening && level > 0) {
      const intensity = level / 100;
      bars.forEach((bar, index) => {
        const targetHeight = 10 + (intensity * 50) + (Math.random() * 20);
        Animated.timing(bar, {
          toValue: targetHeight,
          duration: 100,
          useNativeDriver: true,
        }).start();
      });
    }
  }, [level, isListening]);

  return (
    <View style={styles.container}>
      <View style={styles.waveform}>
        {bars.map((bar, index) => (
          <Animated.View
            key={index}
            style={[
              styles.bar,
              {
                height: bar,
                backgroundColor: isListening ? '#00ff88' : '#333',
                opacity: isListening ? 0.8 + (index / BAR_COUNT) * 0.2 : 0.3,
              },
            ]}
          />
        ))}
      </View>
      {isListening && (
        <View style={styles.listeningIndicator}>
          <View style={styles.dot} />
          <View style={[styles.dot, styles.dot2]} />
          <View style={[styles.dot, styles.dot3]} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 120,
  },
  waveform: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 80,
    width: width - 40,
  },
  bar: {
    width: 4,
    marginHorizontal: 2,
    borderRadius: 2,
    backgroundColor: '#00ff88',
  },
  listeningIndicator: {
    flexDirection: 'row',
    marginTop: 10,
    alignItems: 'center',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#00ff88',
    marginHorizontal: 4,
  },
  dot2: {
    opacity: 0.6,
  },
  dot3: {
    opacity: 0.3,
  },
});