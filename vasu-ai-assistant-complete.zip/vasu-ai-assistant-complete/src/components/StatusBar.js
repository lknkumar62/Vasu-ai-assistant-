import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVasu } from '../context/VasuContext';

export default function StatusBar() {
  const { state } = useVasu();

  return (
    <View style={styles.container}>
      <View style={styles.statusItem}>
        <Ionicons 
          name={state.isOnline ? "wifi" : "wifi-outline"} 
          size={16} 
          color={state.isOnline ? '#00ff88' : '#ff6b6b'} 
        />
        <Text style={[styles.statusText, { color: state.isOnline ? '#00ff88' : '#ff6b6b' }]}>
          {state.isOnline ? 'Online' : 'Offline'}
        </Text>
      </View>

      <View style={styles.statusItem}>
        <Ionicons 
          name={state.deviceStatus.wifi ? "wifi" : "wifi-outline"} 
          size={16} 
          color={state.deviceStatus.wifi ? '#00ff88' : '#666'} 
        />
      </View>

      <View style={styles.statusItem}>
        <Ionicons 
          name={state.deviceStatus.bluetooth ? "bluetooth" : "bluetooth-outline"} 
          size={16} 
          color={state.deviceStatus.bluetooth ? '#00ff88' : '#666'} 
        />
      </View>

      <View style={styles.statusItem}>
        <Ionicons name="battery-half" size={16} color="#00ff88" />
        <Text style={styles.statusText}>{state.deviceStatus.battery}%</Text>
      </View>

      <View style={styles.statusItem}>
        <View style={[styles.statusDot, { 
          backgroundColor: state.systemStatus === 'ready' ? '#00ff88' : 
                         state.systemStatus === 'listening' ? '#ffe66d' : '#00ccff'
        }]} />
        <Text style={styles.statusText}>
          {state.systemStatus === 'ready' ? 'Ready' : 
           state.systemStatus === 'listening' ? 'Listening' : 'Processing'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 8,
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    marginHorizontal: 20,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    color: '#888',
    fontSize: 12,
    marginLeft: 4,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 4,
  },
});