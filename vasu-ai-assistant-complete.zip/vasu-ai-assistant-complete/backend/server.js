const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { OpenAI } = require('openai');
const { exec } = require('child_process');
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

// ========== VOICE PROCESSING ==========
app.post('/api/voice/process', async (req, res) => {
  try {
    const { command, language = 'hi-EN', context = [] } = req.body;

    // Use GPT-4 to understand intent
    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `You are Vasu, an advanced AI voice assistant. You understand both Hindi and English (Hinglish). 
          Parse the user's command and return a JSON response with:
          - intent: the type of command (open_app, call, message, settings, search, media, code, deploy, automation, learn, query)
          - action: specific action to take
          - params: any parameters needed
          - response: natural language response in the same language as the user (Hindi/English mix)`
        },
        ...context.map(c => ({ role: 'user', content: c })),
        { role: 'user', content: command }
      ],
      temperature: 0.3,
    });

    const response = completion.choices[0].message.content;
    let parsedResponse;

    try {
      parsedResponse = JSON.parse(response);
    } catch {
      parsedResponse = {
        intent: 'query',
        action: 'respond',
        params: {},
        response: response
      };
    }

    res.json({
      success: true,
      command,
      ...parsedResponse,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Voice processing error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
      response: 'Maaf kijiye, main samajh nahi paya. Phir se koshish karein.'
    });
  }
});

// ========== CODE GENERATION ==========
app.post('/api/code/generate', async (req, res) => {
  try {
    const { description, language = 'javascript', framework = 'react' } = req.body;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `You are an expert developer. Generate complete, production-ready code based on the user's voice description. 
          Return only the code with brief comments. Language: ${language}, Framework: ${framework}`
        },
        { role: 'user', content: description }
      ],
      temperature: 0.2,
    });

    const code = completion.choices[0].message.content;

    // Save code to file
    const fileName = `generated_${Date.now()}.${language === 'python' ? 'py' : 'js'}`;
    const filePath = path.join(__dirname, 'generated', fileName);

    if (!fs.existsSync(path.join(__dirname, 'generated'))) {
      fs.mkdirSync(path.join(__dirname, 'generated'));
    }

    fs.writeFileSync(filePath, code);

    res.json({
      success: true,
      code,
      fileName,
      filePath,
      language,
      framework,
    });
  } catch (error) {
    console.error('Code generation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== CODE EXECUTION ==========
app.post('/api/code/execute', async (req, res) => {
  try {
    const { code, language = 'javascript' } = req.body;

    let command;
    if (language === 'javascript') {
      command = `node -e "${code.replace(/"/g, '\"')}"`;
    } else if (language === 'python') {
      command = `python3 -c "${code.replace(/"/g, '\"')}"`;
    }

    exec(command, { timeout: 30000 }, (error, stdout, stderr) => {
      if (error) {
        res.json({
          success: false,
          error: stderr || error.message,
          output: stdout,
        });
      } else {
        res.json({
          success: true,
          output: stdout,
          error: stderr,
        });
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== WEB AUTOMATION ==========
app.post('/api/web/automate', async (req, res) => {
  try {
    const { url, actions } = req.body;

    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();

    await page.goto(url, { waitUntil: 'networkidle0' });

    const results = [];
    for (const action of actions) {
      switch (action.type) {
        case 'click':
          await page.click(action.selector);
          results.push({ type: 'click', success: true });
          break;
        case 'type':
          await page.type(action.selector, action.text);
          results.push({ type: 'type', success: true });
          break;
        case 'screenshot':
          const screenshot = await page.screenshot({ encoding: 'base64' });
          results.push({ type: 'screenshot', data: screenshot });
          break;
        case 'scrape':
          const data = await page.evaluate((sel) => {
            return Array.from(document.querySelectorAll(sel)).map(el => el.textContent);
          }, action.selector);
          results.push({ type: 'scrape', data });
          break;
      }
    }

    await browser.close();

    res.json({ success: true, results });
  } catch (error) {
    console.error('Web automation error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== DEPLOYMENT ==========
app.post('/api/deploy', async (req, res) => {
  try {
    const { platform, projectPath, projectName } = req.body;

    let command;
    switch (platform) {
      case 'vercel':
        command = `cd ${projectPath} && vercel --yes --name ${projectName}`;
        break;
      case 'netlify':
        command = `cd ${projectPath} && netlify deploy --prod`;
        break;
      case 'firebase':
        command = `cd ${projectPath} && firebase deploy`;
        break;
      default:
        command = `cd ${projectPath} && npm run build`;
    }

    exec(command, { timeout: 120000 }, (error, stdout, stderr) => {
      if (error) {
        res.json({
          success: false,
          error: stderr || error.message,
          output: stdout,
        });
      } else {
        // Extract URL from output
        const urlMatch = stdout.match(/(https?:\/\/[^\s]+)/);
        res.json({
          success: true,
          output: stdout,
          url: urlMatch ? urlMatch[0] : null,
          platform,
        });
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== SYSTEM COMMANDS ==========
app.post('/api/system/execute', async (req, res) => {
  try {
    const { command, requiresConfirmation = false } = req.body;

    // Safety check for dangerous commands
    const dangerousPatterns = ['rm -rf /', 'format', 'del /', 'rd /'];
    const isDangerous = dangerousPatterns.some(p => command.includes(p));

    if (isDangerous && requiresConfirmation) {
      return res.json({
        success: false,
        requiresConfirmation: true,
        message: 'Yeh command khatarnak ho sakti hai. Confirm karein?'
      });
    }

    exec(command, { timeout: 30000 }, (error, stdout, stderr) => {
      if (error) {
        res.json({ success: false, error: stderr || error.message, output: stdout });
      } else {
        res.json({ success: true, output: stdout, error: stderr });
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== MEMORY/LEARNING ==========
app.post('/api/memory/save', async (req, res) => {
  try {
    const { userId, key, data } = req.body;
    const filePath = path.join(__dirname, 'memory', `${userId}.json`);

    if (!fs.existsSync(path.join(__dirname, 'memory'))) {
      fs.mkdirSync(path.join(__dirname, 'memory'));
    }

    let memory = {};
    if (fs.existsSync(filePath)) {
      memory = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }

    memory[key] = {
      data,
      timestamp: new Date().toISOString(),
    };

    fs.writeFileSync(filePath, JSON.stringify(memory, null, 2));

    res.json({ success: true, message: 'Memory saved' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/memory/get/:userId/:key', async (req, res) => {
  try {
    const { userId, key } = req.params;
    const filePath = path.join(__dirname, 'memory', `${userId}.json`);

    if (!fs.existsSync(filePath)) {
      return res.json({ success: false, message: 'No memory found' });
    }

    const memory = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    res.json({
      success: true,
      data: memory[key] || null,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========== HEALTH CHECK ==========
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    features: [
      'voice_processing',
      'code_generation',
      'code_execution',
      'web_automation',
      'deployment',
      'system_commands',
      'memory_storage'
    ]
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Vasu AI Backend running on port ${PORT}`);
  console.log(`📡 API endpoints ready`);
  console.log(`🤖 OpenAI integration active`);
  console.log(`🌐 Web automation ready`);
});

module.exports = app;